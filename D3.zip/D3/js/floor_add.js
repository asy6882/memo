// floor_add.js — 덮어쓰기용 (세션 PNG 자동 주입 + 기존 편집 로직 유지)

/* ---------------------------
 * DOM refs
 * --------------------------- */

const fileInput = document.getElementById('fileInput');
const img = document.getElementById('img');
const svg = document.getElementById('svg');
const stageInner = document.getElementById('stageInner');
const floatConfirm = document.getElementById('floatConfirm');
const confirmBtn = document.getElementById('confirmBtn');
const cancelBtn = document.getElementById('cancelBtn');
const snapHint = document.getElementById('snapHint');

const naturalSizeEl = document.getElementById('naturalSize');
const ptCountEl = document.getElementById('ptCount');
const lastPxEl = document.getElementById('lastPx');
const lastPctEl = document.getElementById('lastPct');

const undoBtn = document.getElementById('undoBtn');
const clearPtsBtn = document.getElementById('clearPtsBtn');
const clearAllBtn = document.getElementById('clearAllBtn');

const regionNameInput = document.getElementById('regionName');
const saveRegionBtn = document.getElementById('saveRegionBtn');

const jsonText = document.getElementById('jsonText');
const copyJsonBtn = document.getElementById('copyJsonBtn');
const downloadJsonBtn = document.getElementById('downloadJsonBtn');
const importJsonInput = document.getElementById('importJsonInput');
const regionList = document.getElementById('regionList');



/* ---------------------------
 * 상태
 * --------------------------- */
let naturalW = 0, naturalH = 0;
let currentPts = [];              // {x,y,xpct,ypct}
let pending = null;               // {x,y, clientX, clientY, snap:boolean}
let isClosed = false;             // 폴리곤 닫힘 여부
let regions = [];                 // [{name, points:[...]}]

/* ---------------------------
 * 초기화: 세션에서 이미지 받기 (키 호환)
 * --------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  // 호환: 우선순위 lastFloorImage → SION_DRAW_PNG
  const dataURL =
    sessionStorage.getItem('lastFloorImage') ||
    sessionStorage.getItem('SION_DRAW_PNG');

  if (dataURL) {
    if (fileInput) fileInput.style.display = 'none'; // 업로드 UI 숨김

    img.onload = () => {
      naturalW = img.naturalWidth;
      naturalH = img.naturalHeight;
      naturalSizeEl.textContent = `${naturalW} × ${naturalH}px`;
      setupSvgBox();
      resetCurrent();
      renderAll();
      enableUi();
    };
    img.onerror = () => {
      alert('이미지를 불러오지 못했습니다.');
      if (fileInput) fileInput.style.display = '';
      enableUi();
    };
    img.src = dataURL;

    // 한 번 쓰고 지우기(원하면 유지)
    sessionStorage.removeItem('lastFloorImage');
    sessionStorage.removeItem('SION_DRAW_PNG');
  } else {
    // 세션이 없으면 기존 업로드 흐름 유지
    if (fileInput) fileInput.style.display = '';
    enableUi();
  }
});

/* ---------------------------
 * 이미지 업로드(기존 방식 유지)
 * --------------------------- */
if (fileInput) {
  fileInput.addEventListener('change', () => {
    const f = fileInput.files?.[0];
    if (!f) return;
    const url = URL.createObjectURL(f);
    img.onload = () => {
      naturalW = img.naturalWidth;
      naturalH = img.naturalHeight;
      naturalSizeEl.textContent = `${naturalW} × ${naturalH}px`;
      setupSvgBox();
      resetCurrent();
      renderAll();
      enableUi();
    };
    img.onerror = () => {
      alert('이미지를 불러오지 못했습니다.');
      enableUi();
    };
    img.src = url;
  });
}

/* ---------------------------
 * 리사이즈 대응
 * --------------------------- */
window.addEventListener('resize', () => { setupSvgBox(); renderAll(); });

function setupSvgBox() {
  if (!img.src || !naturalW || !naturalH) return;
  const rImg = img.getBoundingClientRect();
  const rStage = stageInner.getBoundingClientRect();
  svg.style.position = 'absolute';
  svg.style.left = (rImg.left - rStage.left) + 'px';
  svg.style.top = (rImg.top - rStage.top) + 'px';

  // 가시 크기에 맞추되, 좌표계는 원본 기준으로 유지(viewBox)
  svg.setAttribute('width', rImg.width);
  svg.setAttribute('height', rImg.height);
  svg.setAttribute('viewBox', `0 0 ${naturalW} ${naturalH}`);
}

/* ---------------------------
 * 클릭 → 임시점 생성 & 스냅 판단
 * --------------------------- */
img.addEventListener('click', (e) => {
  if (!img.src || isClosed) return;
  const { x, y } = visClickToOriginal(e);
  pending = { x, y, clientX: e.clientX, clientY: e.clientY, snap: willSnapToFirst(e) };
  showFloatConfirm(e.clientX, e.clientY, pending.snap);
  renderAll();
});

function visClickToOriginal(e) {
  const rect = img.getBoundingClientRect();
  const xVis = e.clientX - rect.left, yVis = e.clientY - rect.top;
  const x = +(xVis * (naturalW / rect.width)).toFixed(2);
  const y = +(yVis * (naturalH / rect.height)).toFixed(2);
  return { x, y };
}

// 첫 점 근처인지(시각 px 기준)
function willSnapToFirst(e) {
  if (currentPts.length === 0) return false;
  const first = currentPts[0];
  const rect = img.getBoundingClientRect();
  const firstVisX = first.x / naturalW * rect.width + rect.left;
  const firstVisY = first.y / naturalH * rect.height + rect.top;
  const dx = e.clientX - firstVisX;
  const dy = e.clientY - firstVisY;
  const dist = Math.hypot(dx, dy);
  const SNAP_TOL_VIS_PX = 14; // 화면상 14px 이내면 스냅
  return dist <= SNAP_TOL_VIS_PX;
}

// 단축키: Enter=확정, Esc=취소
window.addEventListener('keydown', (e) => {
  if (!pending) return;
  if (e.key === 'Enter') { confirmPending(); }
  if (e.key === 'Escape') { cancelPending(); }
});

if (confirmBtn) confirmBtn.addEventListener('click', confirmPending);
if (cancelBtn) cancelBtn.addEventListener('click', cancelPending);

function confirmPending() {
  if (!pending) return;
  if (pending.snap && currentPts.length >= 2) {
    isClosed = true;
    pending = null;
    hideFloatConfirm();
    updateInfo();
    renderAll();
    enableUi();
    return;
  }
  const { x, y } = pending;
  const xpct = +((x / naturalW) * 100).toFixed(2);
  const ypct = +((y / naturalH) * 100).toFixed(2);
  currentPts.push({ x, y, xpct, ypct });
  pending = null;
  hideFloatConfirm();
  updateInfo();
  renderAll();
  enableUi();
}

function cancelPending() { pending = null; hideFloatConfirm(); renderAll(); }
function showFloatConfirm(clientX, clientY, snapped) {
  const rStage = stageInner.getBoundingClientRect();
  floatConfirm.style.left = (clientX - rStage.left) + 'px';
  floatConfirm.style.top = (clientY - rStage.top) + 'px';
  if (snapHint) snapHint.style.display = snapped ? 'inline' : 'none';
  floatConfirm.style.display = 'flex';
}
function hideFloatConfirm() { floatConfirm.style.display = 'none'; }

/* ---------------------------
 * 편집 버튼들
 * --------------------------- */
if (undoBtn) {
  undoBtn.addEventListener('click', () => {
    if (!currentPts.length || isClosed) return;
    currentPts.pop();
    updateInfo(); renderAll(); enableUi();
  });
}
if (clearPtsBtn) {
  clearPtsBtn.addEventListener('click', () => { resetCurrent(); renderAll(); enableUi(); });
}
if (clearAllBtn) {
  clearAllBtn.addEventListener('click', () => { regions = []; dumpJson(); renderAll(); enableUi(); });
}

function resetCurrent() {
  currentPts = []; pending = null; isClosed = false;
  hideFloatConfirm(); updateInfo();
}

/* ---------------------------
 * 구역 저장 (닫힘+이름)
 * --------------------------- */
if (saveRegionBtn) {
  saveRegionBtn.addEventListener('click', () => {
    const name = regionNameInput.value.trim();
    if (!name) { alert('エリア名を入力してください。'); return; }
    if (!isClosed || currentPts.length < 3) { alert('구역을 스냅으로 닫아 주세요(최소 3점).'); return; }
    regions.push({ name, points: currentPts.map(p => ({ ...p })) });
    regionNameInput.value = '';
    resetCurrent();
    dumpJson(); renderAll(); enableUi();
  });
}

function regionsToJson() {
  try { return JSON.stringify(regions ?? [], null, 2); }
  catch { return '[]'; }
}

/* ---------------------------
 * JSON IO (완료 버튼)
 * --------------------------- */
if (downloadJsonBtn) {
  downloadJsonBtn.addEventListener('click', () => {
    const data = regionsToJson();
    const blob = new Blob([data], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'regions.json';
    a.click();
    URL.revokeObjectURL(a.href);
    window.location.reload();
  });
}

/* ---------------------------
 * 렌더링
 * --------------------------- */
function renderAll() {
  while (svg.firstChild) svg.removeChild(svg.firstChild);

  // 저장된 폴리곤
  regions.forEach(r => {
    if (r.points.length >= 3) {
      const ptsStr = r.points.map(p => `${p.x},${p.y}`).join(' ');
      const poly = mk('polygon', { points: ptsStr, class: 'poly' });
      svg.appendChild(poly);
      const label = mk('text', {
        x: r.points[0].x + 6,
        y: r.points[0].y - 6,
        fill: 'rgba(0,0,0,0.85)',
        'font-size': 14
      });
      label.textContent = r.name;
      svg.appendChild(label);
    }
  });

  // 현재 그리는 도형
  if (currentPts.length) {
    if (isClosed && currentPts.length >= 3) {
      const ptsStr = currentPts.map(p => `${p.x},${p.y}`).join(' ');
      svg.appendChild(mk('polygon', { points: ptsStr, class: 'poly' }));
    } else {
      const d = currentPts.map(p => `${p.x},${p.y}`).join(' ');
      svg.appendChild(mk('polyline', { points: d, class: 'wire' }));
      if (pending && currentPts.length) {
        const last = currentPts[currentPts.length - 1];
        const c = mk('polyline', {
          points: `${last.x},${last.y} ${pending.x},${pending.y}`,
          class: `wire ${pending.snap ? 'wire-snap' : ''}`
        });
        svg.appendChild(c);
      }
    }
    // 점들
    currentPts.forEach((p, i) => {
      svg.appendChild(mk('circle', { cx: p.x, cy: p.y, r: 6, class: `pt ${i === 0 ? 'pt-first' : ''}` }));
      const t = mk('text', { x: p.x + 8, y: p.y - 8, fill: 'rgba(0,0,0,0.85)', 'font-size': 12 });
      t.textContent = i + 1; svg.appendChild(t);
    });
    // 스냅 표시
    if (pending && pending.snap && currentPts.length) {
      const f = currentPts[0];
      // 화면 px 기준 14px 링을 원본 좌표계로 환산
      const ringR = 14 * (naturalW / img.getBoundingClientRect().width);
      svg.appendChild(mk('circle', { cx: f.x, cy: f.y, r: ringR, class: 'snap-halo' }));
      svg.appendChild(mk('circle', { cx: pending.x, cy: pending.y, r: 6, class: 'pt-pending' }));
    } else if (pending) {
      svg.appendChild(mk('circle', { cx: pending.x, cy: pending.y, r: 6, class: 'pt-pending' }));
    }
  }
  renderRegionList();
}

function mk(tag, attrs) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
  Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
  return el;
}

function updateInfo() {
  const n = currentPts.length; ptCountEl.textContent = n;
  if (n) {
    const p = currentPts[n - 1];
    lastPxEl.textContent = `x:${p.x}, y:${p.y}`;
    const xp = p.xpct ?? ((p.x / naturalW * 100).toFixed(2));
    const yp = p.ypct ?? ((p.y / naturalH * 100).toFixed(2));
    lastPctEl.textContent = `x:${xp}%, y:${yp}%`;
  } else {
    lastPxEl.textContent = '-'; lastPctEl.textContent = '-';
  }
}

function dumpJson() { if (!jsonText) return; jsonText.value = regionsToJson(); }

function enableUi() {
  const hasImg = !!img.src;
  const hasPts = currentPts.length > 0;
  const hasRegions = regions.length > 0;
  const canSave = hasImg && isClosed && currentPts.length >= 3 && regionNameInput.value.trim().length > 0;

  if (undoBtn) undoBtn.disabled = !hasPts || isClosed;
  if (clearPtsBtn) clearPtsBtn.disabled = !hasPts && !isClosed;
  if (clearAllBtn) clearAllBtn.disabled = !hasRegions;
  if (saveRegionBtn) saveRegionBtn.disabled = !canSave;
  if (downloadJsonBtn) downloadJsonBtn.disabled = !hasRegions;
  // if (copyJsonBtn) copyJsonBtn.disabled = !hasRegions;

  dumpJson();
}

if (regionNameInput) regionNameInput.addEventListener('input', enableUi);

/* ---------------------------
 * 리스트 렌더링
 * --------------------------- */
function renderRegionList() {
  regionList.innerHTML = '';
  regions.forEach((r, idx) => {
    const div = document.createElement('div'); div.className = 'item mono';
    const ptsPreview = r.points.slice(0, 3).map(p => `(${p.x},${p.y})`).join(', ') + (r.points.length > 3 ? ' ...' : '');
    div.innerHTML = `
      <div><b>${idx + 1}. ${escapeHtml(r.name)}</b> <span class="muted">/ ${r.points.length} pts</span></div>
      <div class="muted">${escapeHtml(ptsPreview)}</div>
      <div class="row" style="margin-top:6px;">
        <button data-act="delete" data-idx="${idx}">削除</button>
      </div>`;
    regionList.appendChild(div);
  });
  regionList.querySelectorAll('button').forEach(b => {
    const idx = +b.dataset.idx, act = b.dataset.act;
    b.addEventListener('click', () => {
      if (act === 'delete') { regions.splice(idx, 1); dumpJson(); renderAll(); enableUi(); }
    });
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[m]));
}


