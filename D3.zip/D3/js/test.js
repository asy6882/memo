// building-facade.js
import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js';

const container = document.getElementById('viewer');

//초기
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
container.appendChild(renderer.domElement);

//이미지색
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;
renderer.toneMappingExposure = 1.0;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf3f6fa);

const camera = new THREE.PerspectiveCamera(55, container.clientWidth / container.clientHeight, 0.1, 5000);
camera.position.set(180, 240, 300);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 60, 0);
controls.update();

scene.add(new THREE.HemisphereLight(0xffffff, 0x667788, 0.7));

const baseHeight = 600;
let rawData = [
    [
        471,
        110
    ],
    [
        833,
        110
    ],
    [
        833,
        154
    ],
    [
        515,
        154
    ],
    [
        515,
        213
    ],
    [
        739,
        213
    ],
    [
        739,
        185
    ],
    [
        913,
        185
    ],
    [
        955,
        90
    ],
    [
        997,
        185
    ],
    [
        1012,
        185
    ],
    [
        1012,
        348
    ],
    [
        818,
        348
    ],
    [
        818,
        353
    ],
    [
        815,
        365
    ],
    [
        811,
        378
    ],
    [
        805,
        389
    ],
    [
        797,
        400
    ],
    [
        787,
        410
    ],
    [
        777,
        419
    ],
    [
        765,
        426
    ],
    [
        753,
        432
    ],
    [
        739,
        436
    ],
    [
        725,
        439
    ],
    [
        711,
        439
    ],
    [
        697,
        439
    ],
    [
        683,
        436
    ],
    [
        670,
        432
    ],
    [
        658,
        426
    ],
    [
        646,
        419
    ],
    [
        635,
        410
    ],
    [
        626,
        400
    ],
    [
        618,
        389
    ],
    [
        612,
        378
    ],
    [
        607,
        365
    ],
    [
        605,
        353
    ],
    [
        604,
        340
    ],
    [
        605,
        327
    ],
    [
        607,
        314
    ],
    [
        612,
        301
    ],
    [
        618,
        290
    ],
    [
        626,
        279
    ],
    [
        635,
        269
    ],
    [
        646,
        260
    ],
    [
        650,
        258
    ],
    [
        471,
        258
    ]
];

const buildingGroup = new THREE.Group();
scene.add(buildingGroup);

const WALLS_GROUP_NAME = 'wallsGroup';



//mode
let mode = 'img';
const btnPrev = document.getElementById('btnPrev');
const btnNext = document.getElementById('btnNext');
const PREV_PAGE_URL = 'building_draw.html';
const NEXT_PAGE_URL = 'floor_add.html';

function setMode(next) {
    mode = next;
    document.querySelector('.img-mode').style.display = (mode === 'img') ? 'inline-block' : 'none';
    document.querySelector('.floor-mode').style.display = (mode === 'floor') ? 'inline-block' : 'none';

    document.getElementById('btnNext').style.display = (mode === 'img') ? 'inline-block' : 'none';
    document.getElementById('btnSaveLevels').style.display = (mode === 'floor') ? 'inline-block' : 'none';

}

btnPrev.addEventListener('click', () => {
    if (mode === 'img') {
        window.location.href = PREV_PAGE_URL;
    } else {
        setMode('img');
    }
});
btnNext.addEventListener('click', () => {
    if (mode === 'img') {
        setMode('floor');
    } else {
        window.location.href = NEXT_PAGE_URL;
    }
})


let buildingBox = new THREE.Box3();  // 월드 기준 바운딩
let baseY = 0, roofY = 0;
let userBoundaries = []; // base/roof 제외한 사용자 경계 Y 목록(오름차순)
let boundaryLinesGroup = null;
let footprintTemplate = null;
let floorWorldY = 0;

function updateBuildingBox() {
    buildingBox.setFromObject(buildingGroup);
    baseY = buildingBox.min.y;
    roofY = buildingBox.max.y;
}

function buildFromPolygon(rawData, baseHeight, floors) {
    if (!rawData || rawData.length < 3) return;

    const polygonPx = rawData.map(([x, y]) => ({ x, y }));

    const PX_TO_UNIT = 0.3;     // 바닥 
    const UNIT_PER_FLOOR = 15;  // 층고 
    const H = floors * UNIT_PER_FLOOR;

    // 픽셀 -> 3D (y반전)
    const to3D = (p) => new THREE.Vector2(
        p.x * PX_TO_UNIT,
        (baseHeight - p.y) * PX_TO_UNIT
    );

    // 1) 중심 정렬 기준 계산
    const pts = polygonPx.map(to3D);
    const minX = Math.min(...pts.map(v => v.x));
    const maxX = Math.max(...pts.map(v => v.x));
    const minZ = Math.min(...pts.map(v => v.y));
    const maxZ = Math.max(...pts.map(v => v.y));
    const cx = (minX + maxX) / 2;
    const cz = (minZ + maxZ) / 2;

    // 2) 그룹 초기화
    buildingGroup.clear();
    const wallsGroup = new THREE.Group();
    wallsGroup.name = 'wallsGroup';
    buildingGroup.add(wallsGroup);
    buildingGroup.position.y = -20;

    // 3) 벽(각 변마다 Plane)
    for (let i = 0; i < pts.length; i++) {
        const a = pts[i], b = pts[(i + 1) % pts.length];
        const ax = a.x - cx, az = a.y - cz;
        const bx = b.x - cx, bz = b.y - cz;

        const dx = bx - ax, dz = bz - az;
        const len = Math.hypot(dx, dz);
        const midX = (ax + bx) / 2, midZ = (az + bz) / 2;
        const ang = Math.atan2(dz, dx);

        const geo = new THREE.PlaneGeometry(len, H);
        const mat = new THREE.MeshStandardMaterial({ color: 0x9bb0c1, side: THREE.DoubleSide });
        const wall = new THREE.Mesh(geo, mat);
        wall.position.set(midX, H / 2, midZ);
        wall.rotation.set(0, -ang, 0);
        wall.castShadow = true;
        wallsGroup.add(wall);
    }

    // 4) 바닥/지붕 캡(Shape → XZ 평면)
    const capShape = new THREE.Shape();
    pts.forEach((v, i) => {
        const x = v.x - cx, z = v.y - cz; // 중심 보정 좌표
        if (i === 0) capShape.moveTo(x, z); else capShape.lineTo(x, z);
    });
    capShape.closePath();

    const capGeo = new THREE.ShapeGeometry(capShape);
    capGeo.rotateX(-Math.PI / 2); // XY → XZ

    const capMat = new THREE.MeshStandardMaterial({ color: 0x9bb0c1, side: THREE.DoubleSide });

    const floor = new THREE.Mesh(capGeo.clone(), capMat.clone());
    floor.position.y = 0;
    floor.rotateX(Math.PI);

    const roof = new THREE.Mesh(capGeo.clone(), capMat.clone());
    roof.position.y = H;
    roof.rotateX(Math.PI);

    wallsGroup.add(floor, roof);
    if (footprintTemplate) {
        footprintTemplate.geometry?.dispose?.();
        footprintTemplate = null;
    }

    // 바닥 윤곽선 추출 
    const edgesGeo = new THREE.EdgesGeometry(floor.geometry, 1);
    edgesGeo.rotateX(-Math.PI / 2);

    floor.updateWorldMatrix(true, true);

    // 라인 오브젝트 만들고, 바닥의 월드 변환을 적용해 "월드 좌표"로 굽기
    const tmpLine = new THREE.LineSegments(edgesGeo);
    tmpLine.applyMatrix4(floor.matrixWorld);

    // 월드 Y(바닥 높이) 보관
    const wp = new THREE.Vector3();
    floor.getWorldPosition(wp);
    floorWorldY = wp.y;

    // 템플릿 보관 (지오메트리만 쓰면 됨)
    footprintTemplate = tmpLine;

    // 바운딩 갱신 + 경계 재그리기
    // updateBuildingBox();
    // userBoundaries = userBoundaries.filter(y => y > baseY && y < roofY).sort((a, b) => a - b);
    // drawBoundaryLines();
    updateBuildingBox();
    userBoundaries = userBoundaries.filter(y => y > baseY && y < roofY);
    drawBoundaryLines();

}

// UI
const floorsInput = document.getElementById('floors');
const buildBtn = document.getElementById('createBuilding');
function createBuilding() {
    const floors = Math.max(1, Number(floorsInput.value || 1));
    buildFromPolygon(rawData, baseHeight, floors);
}
createBuilding();
buildBtn.addEventListener('click', createBuilding);



// 클릭 → 해당 "면(벽)"만 텍스처 적용
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const fileInput = document.getElementById('fileInput');
let pendingWall = null;

renderer.domElement.addEventListener('dblclick', (e) => {
    if (mode !== 'img') return;
    const hit = raycast(e, getWallsChildren());
    if (!hit) return;
    pendingWall = hit.object;
    fileInput.value = '';
    fileInput.click();
});

fileInput.addEventListener('change', (e) => {
    if (mode !== 'img') return;
    const f = e.target.files?.[0];
    if (!f || !pendingWall) return;

    const url = URL.createObjectURL(f);
    new THREE.TextureLoader().load(url, (tex) => {
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        tex.anisotropy = renderer.capabilities.getMaxAnisotropy?.() || 1;
        tex.needsUpdate = true;

        pendingWall.material = new THREE.MeshBasicMaterial({
            map: tex,
            side: THREE.DoubleSide,
            color: 0xffffff,
            transparent: false,
            opacity: 1.0
        });
        pendingWall = null;
    });
});


//층
const MIN_GAP = 0.5;   // 두 경계 최소 간격(m)
const SNAP = 0.1;      // 스냅 단위(m)
const STORAGE_KEY = 'levels:B001';


function getWallsChildren() {
    const g = buildingGroup.getObjectByName(WALLS_GROUP_NAME);
    return g ? g.children : [];
} //벽 그룹에서 벽 가져오기

function raycast(evt, targets) {
    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((evt.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((evt.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    const hits = raycaster.intersectObjects(targets, true);
    return hits[0] || null;
} //클릭 충돌 감지

function snap(v) {
    return Math.round(v / SNAP) * SNAP;
} // 반올림

function addBoundary(y) {
    updateBuildingBox();

    // base/roof 범위 체크
    if (!(y > baseY && y < roofY)) return false;
    y = snap(y);
    // 최소 간격 체크
    const all = [baseY, ...userBoundaries, roofY].sort((a, b) => a - b);
    for (const b of all) {
        if (Math.abs(b - y) < MIN_GAP) {
            return false;
        }
    }
    userBoundaries.push(y);
    userBoundaries.sort((a, b) => a - b);
    drawBoundaryLines();
    return true;
}

function removeBoundaryNear(y) {
    updateBuildingBox();

    if (!userBoundaries.length) return false;

    const ySnap = snap(y);

    // 가장 가까운 경계 찾기
    let bestIdx = -1, bestDist = Infinity;
    for (let i = 0; i < userBoundaries.length; i++) {
        const d = Math.abs(userBoundaries[i] - ySnap);
        if (d < bestDist) { bestDist = d; bestIdx = i; }
    }

    const THRESH = Math.max(MIN_GAP * 1.5, SNAP * 2);

    if (bestIdx !== -1 && bestDist <= THRESH) {
        const removed = userBoundaries.splice(bestIdx, 1)[0];
        drawBoundaryLines();
        // console.debug('removed', { removed, y, ySnap, bestDist, THRESH, userBoundaries });
        return true;
    }
    // console.debug('no boundary close enough', { y, ySnap, bestDist, THRESH, userBoundaries });
    return false;
}

function currentBoundaries() {
    return [baseY, ...userBoundaries, roofY];
} //현재 경계 리스트

function drawBoundaryLines() {
    // 기존 라인 제거 + dispose
    if (boundaryLinesGroup) {
        boundaryLinesGroup.traverse(o => { o.geometry?.dispose?.(); o.material?.dispose?.(); });
        scene.remove(boundaryLinesGroup);
        boundaryLinesGroup = null;
    }
    boundaryLinesGroup = new THREE.Group();
    scene.add(boundaryLinesGroup);

    // 템플릿 없으면(아직 건물 안 만들어졌거나 실패) 빠져나감
    if (!footprintTemplate) return;

    const boundaries = currentBoundaries(); // [baseY, ...userBoundaries, roofY]

    for (const y of boundaries) {
        // 템플릿 복제 (지오메트리는 공유 가능)
        const line = new THREE.LineSegments(
            footprintTemplate.geometry,                       // 템플릿 지오 공유
            new THREE.LineBasicMaterial({ color: 0x00ffff, transparent: true, opacity: 0.9 })
        );
        line.rotation.x = -Math.PI / 2;


        // 템플릿은 '바닥 높이(floorWorldY)'에 구워져 있으니, 원하는 y까지 ΔY만큼 올려줌
        line.position.y = y;

        // 라인 추가
        boundaryLinesGroup.add(line);
    }
}


//json 저장
function saveLevels() {
    const payload = {
        version: 1,
        buildingId: 'B001',
        baseY, roofY,
        userBoundaries: userBoundaries.slice(),
        boundaries: currentBoundaries()
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
}

function getWallsOnly() {
    const g = buildingGroup.getObjectByName(WALLS_GROUP_NAME);
    if (!g) return [];
    // 지붕/바닥 메쉬는 제외
    return g.children.filter(o => o.name !== 'floorCap' && o.name !== 'roofCap');
}

renderer.domElement.addEventListener('click', (e) => {
    if (mode !== 'floor') return;

    const hit = raycast(e, getWallsOnly());   // 지붕/바닥 제외한 '벽'만
    if (!hit) return;

    const y = hit.point.y;

    if (e.altKey || e.metaKey) {
        if (removeBoundaryNear(y)) console.log('경계 삭제');
        else console.log('가까운 경계 없음');
        return;
    }

    if (addBoundary(y)) console.log('경계 추가');  // ✅ 딱 한 번만 호출
});

// 버튼
document.getElementById('btnSaveLevels').addEventListener('click', () => {
    saveLevels(); 
    window.location.href = 'floor_add.html';
});
document.getElementById('btnClearGuides').addEventListener('click', () => {
    if (boundaryLinesGroup) { scene.remove(boundaryLinesGroup); boundaryLinesGroup = null; }
});

// function flash(msg) {
//     if (!toast) return;
//     toast.textContent = msg;
//     toast.style.opacity = '1';
//     clearTimeout(flash._t);
//     flash._t = setTimeout(() => toast.style.opacity = '0', 1200);
// }




// 리사이즈/렌더
window.addEventListener('resize', () => {
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
});
renderer.setAnimationLoop(() => renderer.render(scene, camera));

updateBuildingBox();
drawBoundaryLines();