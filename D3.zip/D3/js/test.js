
import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js';

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 5000);
camera.position.set(50, 120, 150);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 50, 0);
controls.update();

scene.add(new THREE.HemisphereLight(0xffffff, 0x667788, 0.7));

const baseHeight = 600;

//test polygon　座標 나중에 json 받으면 raw데이터를 변환해야댐
let polygonEx = [
  { x: 548, y: 241 },
  { x: 646, y: 241 },
  { x: 704, y: 125 },
  { x: 762, y: 241 },
  { x: 869, y: 241 },
  { x: 869, y: 415 },
  { x: 548, y: 415 }
];

// buildingを作る
let buildingGroup = new THREE.Group();
scene.add(buildingGroup);

function buildFromPolygon(polygonPx, baseHeight, floors) {
    if (!polygonPx || polygonPx.length < 3) return; //점 3개 이상이어야 생성 가능함

    const PX_TO_UNIT = 0.3;   // 1px -> 0.1 유닛 (바닥 축소)
    const UNIT_PER_FLOOR = 15; // 1층 높이 3 유닛 (높이 확대)

    //pixel座標　ー＞　3D座標
    const to3D = (p) => new THREE.Vector2(
        p.x * PX_TO_UNIT,
        (baseHeight - p.y) * PX_TO_UNIT
    );

    const shape = new THREE.Shape();
    polygonPx.forEach((pt, i) => {
        const v = to3D(pt);
        if (i === 0) shape.moveTo(v.x, v.y);
        else shape.lineTo(v.x, v.y);
    });
    shape.closePath();

    const totalHeight = floors * UNIT_PER_FLOOR; 
    const geom = new THREE.ExtrudeGeometry(shape, {
        depth: totalHeight,
        bevelEnabled: false
    });

    geom.rotateX(-Math.PI / 2); //ExtrudeGeometry가 z축(앞뒤)로 길어져서 그걸 위로 쌓을 수 있게 돌리는거
    geom.computeBoundingBox(); //도형이 차지하는 최소 직육면체 범위 
    const bb = geom.boundingBox; //위에서 계산한 도형의 경계박스 
    const cx = (bb.min.x + bb.max.x) / 2; //x 중심 좌표
    const cz = (bb.min.z + bb.max.z) / 2; //y 중심 좌표
    const dy = -bb.min.y; //바닥 최소값 0으로 맞추기 위해서 위로 올릴 거리
    geom.translate(-cx, dy, -cz);


    const mat = new THREE.MeshStandardMaterial({ color: 0x9bb0c1 });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.castShadow = true;
    mesh.receiveShadow = true;

    const edges = new THREE.LineSegments(
        new THREE.EdgesGeometry(geom),
        new THREE.LineBasicMaterial({ color: 0x394b59 })
    );

    buildingGroup.clear();
    buildingGroup.add(mesh);
    buildingGroup.add(edges);
}

const floorsInput = document.getElementById('floors');
const buildBtn = document.getElementById('createBuilding');

function createBuilding() {
    const floors = Math.max(1, Number(floorsInput.value || 1));
    buildFromPolygon(polygonEx, baseHeight, floors);
}

createBuilding(); // 초기 실행
buildBtn.addEventListener('click', createBuilding);


//렌더 루프
window.addEventListener('resize', () => {
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
});

renderer.setAnimationLoop(() => {
    renderer.render(scene, camera);
});