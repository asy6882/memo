// building-facade.js
import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js';

const container = document.getElementById('viewer');

//초기
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
container.appendChild(renderer.domElement);

//이미지색
renderer.outputColorSpace = THREE.SRGBColorSpace; 
renderer.toneMapping = THREE.NoToneMapping; 
renderer.toneMappingExposure = 1.0;  

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf3f6fa);

const camera = new THREE.PerspectiveCamera(55, container.clientWidth / container.clientHeight, 0.1, 5000);
camera.position.set(180, 240, 300);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 60, 0);
controls.update();

scene.add(new THREE.HemisphereLight(0xffffff, 0x667788, 0.7));

const baseHeight = 600;
let rawData = [
    [
        568,
        152
    ],
    [
        934,
        152
    ],
    [
        934,
        342
    ],
    [
        568,
        342
    ]
];

const buildingGroup = new THREE.Group();
scene.add(buildingGroup);

function buildFromPolygon(rawData, baseHeight, floors) {
    if (!rawData || rawData.length < 3) return;

    const polygonPx = rawData.map(([x, y]) => ({ x, y }));

    const PX_TO_UNIT = 0.3;     // 바닥 스케일
    const UNIT_PER_FLOOR = 15;  // 층고 스케일
    const H = floors * UNIT_PER_FLOOR;

    // 픽셀 -> 3D (y반전)
    const to3D = (p) => new THREE.Vector2(
        p.x * PX_TO_UNIT,
        (baseHeight - p.y) * PX_TO_UNIT
    );

    // 1) 중심 정렬 기준 계산
    const pts = polygonPx.map(to3D);
    const minX = Math.min(...pts.map(v => v.x));
    const maxX = Math.max(...pts.map(v => v.x));
    const minZ = Math.min(...pts.map(v => v.y));
    const maxZ = Math.max(...pts.map(v => v.y));
    const cx = (minX + maxX) / 2;
    const cz = (minZ + maxZ) / 2;

    // 2) 그룹 초기화
    buildingGroup.clear();
    const wallsGroup = new THREE.Group();
    wallsGroup.name = 'wallsGroup';
    buildingGroup.add(wallsGroup);
    buildingGroup.position.y = -20;

    // 3) 벽(각 변마다 Plane)
    for (let i = 0; i < pts.length; i++) {
        const a = pts[i], b = pts[(i + 1) % pts.length];
        const ax = a.x - cx, az = a.y - cz;
        const bx = b.x - cx, bz = b.y - cz;

        const dx = bx - ax, dz = bz - az;
        const len = Math.hypot(dx, dz);
        const midX = (ax + bx) / 2, midZ = (az + bz) / 2;
        const ang = Math.atan2(dz, dx);

        const geo = new THREE.PlaneGeometry(len, H);
        const mat = new THREE.MeshStandardMaterial({ color: 0x9bb0c1, side: THREE.DoubleSide });
        const wall = new THREE.Mesh(geo, mat);
        wall.position.set(midX, H / 2, midZ);
        wall.rotation.set(0, -ang, 0);
        wall.castShadow = true;
        wallsGroup.add(wall);
    }

    // 4) 바닥/지붕 캡(Shape → XZ 평면)
    const capShape = new THREE.Shape();
    pts.forEach((v, i) => {
        const x = v.x - cx, z = v.y - cz; // 중심 보정 좌표
        if (i === 0) capShape.moveTo(x, z); else capShape.lineTo(x, z);
    });
    capShape.closePath();

    const capGeo = new THREE.ShapeGeometry(capShape);
    capGeo.rotateX(-Math.PI / 2); // XY → XZ

    const capMat = new THREE.MeshStandardMaterial({ color: 0x9bb0c1, side: THREE.DoubleSide });

    const floor = new THREE.Mesh(capGeo.clone(), capMat.clone());
    floor.position.y = 0;
    floor.rotateX(Math.PI);

    const roof = new THREE.Mesh(capGeo.clone(), capMat.clone());
    roof.position.y = H;
    roof.rotateX(Math.PI);

    wallsGroup.add(floor, roof);
}

// UI
const floorsInput = document.getElementById('floors');
const buildBtn = document.getElementById('createBuilding');
function createBuilding() {
    const floors = Math.max(1, Number(floorsInput.value || 1));
    buildFromPolygon(rawData, baseHeight, floors);
}
createBuilding();
buildBtn.addEventListener('click', createBuilding);

// 클릭 → 해당 "면(벽)"만 텍스처 적용
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const fileInput = document.getElementById('fileInput');
let pendingWall = null;

renderer.domElement.addEventListener('dblclick', (e) => {
    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);
    const wallsGroup = buildingGroup.getObjectByName('wallsGroup');
    if (!wallsGroup) return;

    const hits = raycaster.intersectObjects(wallsGroup.children, true);
    if (!hits.length) return;

    pendingWall = hits[0].object;
    fileInput.value = '';
    fileInput.click();
});

fileInput.addEventListener('change', (e) => {
    const f = e.target.files?.[0];
    if (!f || !pendingWall) return;

    const url = URL.createObjectURL(f);
    new THREE.TextureLoader().load(url, (tex) => {
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        tex.anisotropy = renderer.capabilities.getMaxAnisotropy?.() || 1;
        tex.needsUpdate = true;

        pendingWall.material = new THREE.MeshBasicMaterial({
            map: tex,
            side: THREE.DoubleSide,
            color: 0xffffff,
            transparent: false,
            opacity: 1.0
        });
        pendingWall = null;
    });
});

// 리사이즈/렌더
window.addEventListener('resize', () => {
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
});
renderer.setAnimationLoop(() => renderer.render(scene, camera));
