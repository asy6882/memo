(() => {
  /* =========================================================
   * [세션 0] 기본 레퍼런스 / 상태 / 상수
   * =======================================================*/
  // 캔버스/컨텍스트/상태 텍스트 영역
  const canvas = document.getElementById('canvas');
  const ctx = canvas.getContext('2d');
  const statusEl = document.getElementById('status');

  // 툴바/그룹/해제/삭제/스냅/그리드/저장 버튼
  const toolrail = document.querySelector('.toolrail');
  const btnGroup = document.getElementById('btnGroup');
  const btnUngroup = document.getElementById('btnUngroup');
  const btnDelete = document.getElementById('btnDelete');
  const chkSnap = document.getElementById('chkSnap');
  const gridSizeInput = document.getElementById('gridSize');
  const btnSaveJSON = document.getElementById('btnSaveJSON');

  // 타원 텍스처 클립 모드: 'whole' = 타원 전체 1장, 'caps' = 분할 캡별
  const ELLIPSE_CLIP_MODE = 'whole';

  // polygon-clipping 라이브러리(boolean 연산용) 지연 로딩 핸들
  let pcLib = null;

  async function ensurePc() {
    if (pcLib) return pcLib;
    if (window.polygonClipping) { pcLib = window.polygonClipping; return pcLib; }
    try {
      const mod = await import('https://esm.run/polygon-clipping@0.15.3');
      pcLib = mod && (mod.default || mod);
    } catch (e) {
      console.error('polygon-clipping ロード失敗:', e);
      pcLib = null;
    }
    return pcLib;
  }

  // 툴바 아이콘 클릭 → 현재 툴 설정 및 active 표시
  toolrail?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-tool]');
    if (!btn || !toolrail.contains(btn)) return;
    setTool(btn.dataset.tool);
    document.querySelectorAll('.toolrail .iconbtn[data-tool]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });

  // 에디터 상태
  const state = {
    tool: 'select',
    objects: [],
    selection: new Set(),
    maybeDragging: false,
    dragging: false,
    dragStart: { x: 0, y: 0 },

    // 리사이즈/회전
    resizing: false,
    rotating: false,
    activeHandle: null,
    resizeTargetId: null,
    resizeStartMouse: { x: 0, y: 0 },
    resizeStartBBox: null,
    resizeRefPoints: null,
    rotateTargetId: null,
    rotateStartMouse: { x: 0, y: 0 },
    rotateStartAngle: 0,
    rotateAnchor: null,

    // 그룹 회전
    groupResizeSnapshot: null,
    groupRotateSnapshot: null,

    // 생성 중 (드래그)
    creating: null,

    // 기타
    lastMouse: { x: 0, y: 0 },
    gridSize: 10,
    snap: false,
    keymods: { shift: false, alt: false },
    resizeStartThick: { tV: null, tH: null },
    tracing: false,
    tracePoints: [],
  };

  // UI/잡다 상수들
  const HANDLE_SIZE = 12;
  const ROTATE_HANDLE_OFFSET = 22;
  const HIT_PAD = 8;
  const DRAG_START_THRESHOLD = 6;
  const GROUP_HIDE_INNER_STROKES = true;

  // L/C 모양 두께 조절
  const THICK_SENS = 0.35;
  const THICK_STEP = 2;
  const THICK_FINE = 0.4;
  const THICK_COARSE = 1.8;
  function roundTo(v, step) { return Math.round(v / step) * step; }

  // 유틸: id 생성, 편의함수
  let _id = 1;
  const genId = () => `id_${_id++}`;
  function rad2deg(r) { return r * 180 / Math.PI; }
  function snap(v) { return state.snap ? Math.round(v / state.gridSize) * state.gridSize : v; }
  function pointInRect(px, py, x, y, w, h) { return px >= x && px <= x + w && py >= y && py <= y + h; }
  function rotatePoint(px, py, cx, cy, ang) {
    const s = Math.sin(ang), c = Math.cos(ang);
    const dx = px - cx, dy = py - cy;
    return { x: cx + dx * c - dy * s, y: cy + dx * s + dy * c };
  }
  function invRotatePoint(px, py, cx, cy, ang) { return rotatePoint(px, py, cx, cy, -ang); }
  function groupCenter(g) { const b = g.bbox(); return { cx: b.x + b.w / 2, cy: b.y + b.h / 2 }; }

  // 도형 생성 툴 목록
  const SHAPE_TOOLS = new Set(['rect', 'tri', 'circle', 'lshape', 'cshape']);
  function setActiveToolButton(t) {
    document.querySelectorAll('.toolrail [data-tool]').forEach(b => {
      b.classList.toggle('active', b.dataset.tool === t);
    });
  }

  /* =========================================================
   * [세션 1] 도형 클래스 계층
   * =======================================================*/
  class Shape {
    constructor(type, opts = {}) {
      this.kind = 'shape';
      this.id = genId();
      this.type = type;
      this.x = opts.x ?? 100;
      this.y = opts.y ?? 100;
      this.w = opts.w ?? 120;
      this.h = opts.h ?? 80;
      this.fill = opts.fill ?? '#f5f9ffff';
      this.stroke = opts.stroke ?? '#222';
      this.lineWidth = opts.lineWidth ?? 2;
      this.meta = opts.meta || {};
      this.angle = opts.angle ?? 0;
    }
    get cx() { return this.x + this.w / 2; }
    get cy() { return this.y + this.h / 2; }
    bbox() { return { x: this.x, y: this.y, w: this.w, h: this.h }; }
    moveBy(dx, dy) { this.x += dx; this.y += dy; }

    // 선택 시 외곽 점선+핸들 렌더
    drawSelectedOutline() {
      const corners = [
        { x: this.x, y: this.y },
        { x: this.x + this.w, y: this.y },
        { x: this.x + this.w, y: this.y + this.h },
        { x: this.x, y: this.y + this.h },
      ].map(p => rotatePoint(p.x, p.y, this.cx, this.cy, this.angle));
      ctx.save();
      ctx.setLineDash([4, 3]);
      ctx.lineWidth = 1;
      ctx.strokeStyle = '#00bcd4';
      ctx.beginPath();
      ctx.moveTo(corners[0].x, corners[0].y);
      for (let i = 1; i < corners.length; i++) ctx.lineTo(corners[i].x, corners[i].y);
      ctx.closePath(); ctx.stroke();
      ctx.restore();
      drawHandles(this);
    }

    // 회전 적용된 좌표계로 그리기
    _withRotation(c, drawBody) { c.save(); c.translate(this.cx, this.cy); c.rotate(this.angle); drawBody(); c.restore(); }

    // 직렬화(저장용 최소 필드)
    toJSON() { return { id: this.id, type: this.type, x: this.x, y: this.y, w: this.w, h: this.h }; }
  }

  // 사각형
  class Rect extends Shape {
    constructor(opts) { super('rect', opts); }
    draw() {
      this._withRotation(ctx, () => {
        ctx.fillStyle = this.fill;
        ctx.fillRect(-this.w / 2, -this.h / 2, this.w, this.h);
        ctx.lineWidth = this.lineWidth;
        ctx.strokeStyle = this.stroke;
        ctx.strokeRect(-this.w / 2, -this.h / 2, this.w, this.h);
      });
    }
    // 클릭 히트 테스트(회전 보정 좌표계로 검사)
    hit(px, py) {
      const p = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      return pointInRect(p.x, p.y, this.x, this.y, this.w, this.h);
    }
  }

  // 삼각형(등변)
  class Tri extends Shape {
    constructor(opts) { super('tri', opts); }
    pathLocal() {
      const w = this.w, h = this.h;
      const p = new Path2D();
      p.moveTo(0, -h / 2);
      p.lineTo(w / 2, h / 2);
      p.lineTo(-w / 2, h / 2);
      p.closePath();
      return p;
    }
    draw() {
      this._withRotation(ctx, () => {
        const p = this.pathLocal();
        ctx.fillStyle = this.fill;
        ctx.fill(p);
        ctx.lineWidth = this.lineWidth;
        ctx.strokeStyle = this.stroke;
        ctx.stroke(p);
      });
    }
    hit(px, py) {
      const lp = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      const p = this.pathLocal();
      return ctx.isPointInPath(p, lp.x - this.cx, lp.y - this.cy);
    }
  }

  // 원/타원
  class Circle extends Shape {
    constructor(opts) { super('circle', opts); }
    draw() {
      this._withRotation(ctx, () => {
        const rx = this.w / 2, ry = this.h / 2;
        ctx.beginPath();
        ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
        ctx.fillStyle = this.fill;
        ctx.fill();
        ctx.lineWidth = this.lineWidth;
        ctx.strokeStyle = this.stroke;
        ctx.stroke();
      });
    }
    hit(px, py) {
      const p = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      const rx = Math.max(this.w / 2, 1e-6);
      const ry = Math.max(this.h / 2, 1e-6);
      const nx = (p.x - this.cx) / rx;
      const ny = (p.y - this.cy) / ry;
      return nx * nx + ny * ny <= 1;
    }
  }

  // L 형태(ㄱ자) — 수평/수직 두께(tH/tV) 조절 가능
  class LShape extends Shape {
    constructor(opts) {
      super('lshape', opts);
      const base = Math.min(this.w, this.h);
      this.tH = opts?.tH ?? base * 0.4; // 가로 띠 두께
      this.tV = opts?.tV ?? base * 0.4; // 세로 띠 두께
    }
    pathLocal() {
      const w = this.w, h = this.h, tH = this.tH, tV = this.tV;
      const p = new Path2D();
      // 로컬 좌표(중심 기준)에서 외곽을 시계방향으로 그리기
      p.moveTo(-w / 2, -h / 2);
      p.lineTo(w / 2, -h / 2);
      p.lineTo(w / 2, -h / 2 + tH);
      p.lineTo(-w / 2 + tV, -h / 2 + tH);
      p.lineTo(-w / 2 + tV, h / 2);
      p.lineTo(-w / 2, h / 2);
      p.closePath();
      return p;
    }
    draw() {
      this._withRotation(ctx, () => { const p = this.pathLocal(); ctx.fillStyle = this.fill; ctx.fill(p); ctx.lineWidth = this.lineWidth; ctx.strokeStyle = this.stroke; ctx.stroke(p); });
    }
    hit(px, py) {
      const lp = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      const p = this.pathLocal();
      return ctx.isPointInPath(p, lp.x - this.cx, lp.y - this.cy);
    }
    toJSON() { const j = super.toJSON(); j.tH = this.tH; j.tV = this.tV; return j; }
  }

  // C 형태(ㄷ자) — 수평/수직 두께(tH/tV) 조절 가능
  class CShape extends Shape {
    constructor(opts) {
      super('cshape', opts);
      const base = Math.min(this.w, this.h);
      this.tH = opts?.tH ?? base * 0.3;
      this.tV = opts?.tV ?? base * 0.3;
    }
    pathLocal() {
      const w = this.w, h = this.h, tH = this.tH, tV = this.tV;
      const p = new Path2D();
      p.moveTo(-w / 2, -h / 2);
      p.lineTo(w / 2, -h / 2);
      p.lineTo(w / 2, -h / 2 + tH);
      p.lineTo(-w / 2 + tV, -h / 2 + tH);
      p.lineTo(-w / 2 + tV, h / 2 - tH);
      p.lineTo(w / 2, h / 2 - tH);
      p.lineTo(w / 2, h / 2);
      p.lineTo(-w / 2, h / 2);
      p.closePath();
      return p;
    }
    draw() {
      this._withRotation(ctx, () => { const p = this.pathLocal(); ctx.fillStyle = this.fill; ctx.fill(p); ctx.lineWidth = this.lineWidth; ctx.strokeStyle = this.stroke; ctx.stroke(p); });
    }
    hit(px, py) {
      const lp = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      const p = this.pathLocal();
      return ctx.isPointInPath(p, lp.x - this.cx, lp.y - this.cy);
    }
    toJSON() { const j = super.toJSON(); j.tH = this.tH; j.tV = this.tV; return j; }
  }

  // 라인(펜) — 화면상 점찍기 도구(여기서는 히트 없음)
  class LinePen extends Shape {
    constructor(opts) { super('line', opts); }
    draw() { }; hit() { return false; }
  }

  // 다각형(펜으로 찍은 점 기반)
  class Poly extends Shape {
    constructor(points, opts) {
      super('poly', opts);
      this.meta.points = points.map(p => ({ x: p.x, y: p.y }));
      const xs = points.map(p => p.x), ys = points.map(p => p.y);
      this.x = Math.min(...xs); this.y = Math.min(...ys);
      this.w = Math.max(...xs) - this.x; this.h = Math.max(...ys) - this.y;
      this.angle = 0;
    }
    moveBy(dx, dy) {
      this.x += dx; this.y += dy;
      this.meta.points = this.meta.points.map(p => ({ x: p.x + dx, y: p.y + dy }));
    }
    pathWorld() {
      const pth = new Path2D();
      const pts = this.meta.points;
      if (!pts.length) return pth;
      pth.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) pth.lineTo(pts[i].x, pts[i].y);
      pth.closePath();
      return pth;
    }
    draw() {
      const p = this.pathWorld();
      ctx.save();
      ctx.fillStyle = this.fill;
      ctx.fill(p);
      ctx.lineWidth = this.lineWidth;
      ctx.strokeStyle = this.stroke;
      ctx.stroke(p);
      ctx.restore();
    }
    hit(px, py) { return ctx.isPointInPath(this.pathWorld(), px, py); }
    toJSON() {
      const j = super.toJSON();
      j.meta = { points: this.meta.points };
      return j;
    }
  }

  /* =========================================================
   * [세션 2] 그룹(Group) 정의 및 공용 렌더링 유틸
   *  - 그룹 bbox/이동/선택 외곽/직렬화
   *  - fill/stroke 공용 함수(타입별 분기)
   * =======================================================*/

  // 여러 개의 shape를 묶는 그룹
  class Group {
    constructor(children) {
      this.id = genId();
      this.kind = 'group';
      this.children = children; // 자식 shape들의 id 배열
    }
    bbox() {
      const boxes = this.children.map(id => getObj(id).bbox());
      const x = Math.min(...boxes.map(b => b.x));
      const y = Math.min(...boxes.map(b => b.y));
      const r = Math.max(...boxes.map(b => b.x + b.w));
      const b = Math.max(...boxes.map(b => b.y + b.h));
      return { x, y, w: r - x, h: b - y };
    }
    moveBy(dx, dy) { this.children.forEach(id => getObj(id).moveBy(dx, dy)); }
    drawSelectedOutline() {
      const { x, y, w, h } = this.bbox();
      ctx.save();
      ctx.setLineDash([6, 3]);
      ctx.lineWidth = 1.2;
      ctx.strokeStyle = '#10b981';
      ctx.strokeRect(x, y, w, h);
      ctx.restore();
      drawHandles(this);
    }
    toJSON() { return { kind: 'group', id: this.id, children: this.children }; }
  }

  // id로 객체 조회(그룹/도형 공통)
  function getObj(id) { return state.objects.find(o => o && o.id === id); }

  // (회전 적용한 좌표계에서) 콜백으로 그리기
  function withRotationOn(c, obj, fn) { c.save(); c.translate(obj.cx, obj.cy); c.rotate(obj.angle); fn(); c.restore(); }

  // ▼ 채우기 공용
  function fillShapeOn(c, o) {
    c.save();
    c.fillStyle = o.fill;
    if (o.type === 'rect') {
      withRotationOn(c, o, () => c.fillRect(-o.w / 2, -o.h / 2, o.w, o.h));
    } else if (o.type === 'tri') {
      withRotationOn(c, o, () => { const p = o.pathLocal(); c.fill(p); });
    } else if (o.type === 'circle') {
      withRotationOn(c, o, () => { c.beginPath(); c.ellipse(0, 0, o.w / 2, o.h / 2, 0, 0, Math.PI * 2); c.fill(); });
    } else if (o.type === 'lshape' || o.type === 'cshape') {
      withRotationOn(c, o, () => { const p = o.pathLocal(); c.fill(p); });
    } else if (o.type === 'poly') {
      const p = o.pathWorld(); c.fill(p);
    }
    c.restore();
  }

  // ▼ 외곽선 공용
  function strokeShapeOn(c, o) {
    c.save();
    c.lineWidth = o.lineWidth;
    c.strokeStyle = o.stroke;
    if (o.type === 'rect') {
      withRotationOn(c, o, () => c.strokeRect(-o.w / 2, -o.h / 2, o.w, o.h));
    } else if (o.type === 'tri') {
      withRotationOn(c, o, () => { const p = o.pathLocal(); c.stroke(p); });
    } else if (o.type === 'circle') {
      withRotationOn(c, o, () => { c.beginPath(); c.ellipse(0, 0, o.w / 2, o.h / 2, 0, 0, Math.PI * 2); c.stroke(); });
    } else if (o.type === 'lshape' || o.type === 'cshape') {
      withRotationOn(c, o, () => { const p = o.pathLocal(); c.stroke(p); });
    } else if (o.type === 'poly') {
      const p = o.pathWorld(); c.stroke(p);
    }
    c.restore();
  }

  /* =========================================================
   * [세션 3] 내보내기/저장 도우미
   *  - Blob/데이터URL 다운로드
   *  - 화면 렌더(단일/그룹) → 내보낼 때 겹침 처리
   *  - PNG 내보내기(고정 크기/패딩/배경)
   * =======================================================*/

  // a 태그 생성으로 Blob 다운로드
  function downloadBlob(filename, blob) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 0);
  }
  // a 태그 생성으로 dataURL 다운로드
  function downloadDataURL(filename, dataURL) {
    const a = document.createElement('a');
    a.href = dataURL;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { a.remove(); }, 0);
  }

  // 현재 씬을 오프로 렌더(그룹 안쪽 경계선 숨김/겉윤곽 강조)
  function renderExportOn(targetCtx) {
    // 그룹에 포함된 자식 id 집합
    const groupedIds = new Set();
    state.objects.forEach(o => { if (o && o.kind === 'group') o.children.forEach(id => groupedIds.add(id)); });
    targetCtx.clearRect(0, 0, canvas.width, canvas.height);

    // 1) 최상위 개별 도형 먼저 채우고/스트로크
    for (const obj of state.objects) {
      if (!obj || obj.kind === 'group') continue;
      if (!groupedIds.has(obj.id)) {
        fillShapeOn(targetCtx, obj);
        strokeShapeOn(targetCtx, obj);
      }
    }

    // 2) 그룹은 합집합 윤곽으로 스트로크 처리(내부 경계선 제거)
    const lib = pcLib;
    for (const obj of state.objects) {
      if (!obj || obj.kind !== 'group') continue;

      if (!lib) {
        // 라이브러리 없으면 단순히 자식들 stroke
        obj.children.map(getObj).filter(Boolean).forEach(o => {
          fillShapeOn(targetCtx, o);
          strokeShapeOn(targetCtx, o);
        });
        continue;
      }
      const children = obj.children.map(getObj).filter(Boolean);
      children.forEach(o => fillShapeOn(targetCtx, o));

      const multi = groupToPolygons(obj, lib);
      const outlineColor = children[0]?.stroke ?? '#222';
      const outlineWidth = Math.max(2, children[0]?.lineWidth ?? 2);
      drawMultiPolygonStrokeOn(targetCtx, multi, outlineColor, outlineWidth);
    }
  }

  // 도형/그룹의 월드 좌표 bbox 계산
  function worldBBoxOfShape(o) {
    if (o.type === 'poly') {
      const pts = (o.meta.points || []);
      const xs = pts.map(p => p.x), ys = pts.map(p => p.y);
      return {
        x: Math.min(...xs), y: Math.min(...ys),
        w: Math.max(...xs) - Math.min(...xs),
        h: Math.max(...ys) - Math.min(...ys)
      };
    }
    const cx = o.x + o.w / 2, cy = o.y + o.h / 2, ang = o.angle || 0;
    const corners = [
      { x: o.x, y: o.y },
      { x: o.x + o.w, y: o.y },
      { x: o.x + o.w, y: o.y + o.h },
      { x: o.x, y: o.y + o.h },
    ].map(p => rotatePoint(p.x, p.y, cx, cy, ang));
    const xs = corners.map(p => p.x), ys = corners.map(p => p.y);
    return {
      x: Math.min(...xs), y: Math.min(...ys),
      w: Math.max(...xs) - Math.min(...xs),
      h: Math.max(...ys) - Math.min(...ys)
    };
  }

  // 최상위 요소들의 전체 bbox
  function worldBBoxOfTopLevel(topLevel) {
    const boxes = [];
    for (const o of topLevel) {
      if (o.kind === 'group') {
        const children = o.children.map(id => getObj(id)).filter(Boolean);
        children.forEach(ch => boxes.push(worldBBoxOfShape(ch)));
      } else {
        boxes.push(worldBBoxOfShape(o));
      }
    }
    if (!boxes.length) return null;
    const x1 = Math.min(...boxes.map(b => b.x));
    const y1 = Math.min(...boxes.map(b => b.y));
    const x2 = Math.max(...boxes.map(b => b.x + b.w));
    const y2 = Math.max(...boxes.map(b => b.y + b.h));
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
  }

  // 오프로 컨텍스트에 최상위 요소 렌더(그룹은 윤곽 병합 처리)
  function renderTopLevelOn(ctx2, topLevel) {
    for (const o of topLevel) {
      if (o.kind === 'group') {
        const children = o.children.map(id => getObj(id)).filter(Boolean);
        children.forEach(ch => { fillShapeOn(ctx2, ch); });

        if (pcLib) {
          const multi = groupToPolygons(o, pcLib);
          const outlineColor = children[0]?.stroke ?? '#222';
          const outlineWidth = Math.max(2, children[0]?.lineWidth ?? 2);
          drawMultiPolygonStrokeOn(ctx2, multi, outlineColor, outlineWidth);
        } else {
          children.forEach(ch => { strokeShapeOn(ctx2, ch); });
        }
      } else {
        fillShapeOn(ctx2, o);
        strokeShapeOn(ctx2, o);
      }
    }
  }

  // 바운딩 박스 기준 정사각형 PNG 뽑기(패딩/배경색 옵션)
  async function exportPNGFixedBlob(size = 1200, padding = 20, background = null) {
    const childIds = new Set();
    state.objects.forEach(o => { if (o && o.kind === 'group') o.children.forEach(id => childIds.add(id)); });
    const topLevel = state.objects.filter(o => o && (o.kind === 'group' || !childIds.has(o.id)));
    if (!topLevel.length) return null;

    // 전체 bbox 기준으로 가운데 정렬/스케일링
    const bbox = worldBBoxOfTopLevel(topLevel);
    if (!bbox || bbox.w <= 0 || bbox.h <= 0) return null;

    const drawArea = size - padding * 2;
    const scale = Math.min(drawArea / bbox.w, drawArea / bbox.h);
    const drawW = bbox.w * scale, drawH = bbox.h * scale;
    const offsetX = (size - drawW) / 2;
    const offsetY = (size - drawH) / 2;

    // 오프로 캔버스 생성
    const off = document.createElement('canvas');
    off.width = size; off.height = size;
    const octx = off.getContext('2d');

    if (background) {
      octx.fillStyle = background;
      octx.fillRect(0, 0, size, size);
    }

    // 스케일/이동 후 렌더
    octx.save();
    octx.translate(offsetX, offsetY);
    octx.scale(scale, scale);
    octx.translate(-bbox.x, -bbox.y);
    renderTopLevelOn(octx, topLevel);
    octx.restore();

    return new Promise(resolve => off.toBlob(b => resolve(b), 'image/png'));
  }

  // 전체 화면 그대로 PNG 저장(캔버스 크기 그대로)
  function exportPNG(filename = 'floor.png') {
    const off = document.createElement('canvas');
    off.width = canvas.width;
    off.height = canvas.height;
    const octx = off.getContext('2d');
    renderExportOn(octx);
    const url = off.toDataURL('image/png');
    downloadDataURL(filename, url);

    //세션 추가
    const buildingId = sessionStorage.getItem('currentBuildingId') || 'B001';
    sessionStorage.setItem(`bld:${buildingId}:sectionImage`, url);
    sessionStorage.setItem('lastFloorImage', url);
  }

  /* =========================================================
   * [세션 4] 화면 렌더 루프
   *  - 그리드/개별 도형/그룹/선택 외곽/라인 미리보기/생성 미리보기
   * =======================================================*/

  // 배경 그리드
  function drawGrid() {
    const g = state.gridSize;
    ctx.save();
    ctx.lineWidth = 0.5;
    ctx.strokeStyle = '#eee';
    for (let x = 0; x < canvas.width; x += g) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += g) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
    }
    ctx.restore();
  }

  // 멀티폴리곤(합집합 결과) 채우기/스트로크 유틸
  function drawMultiPolygonFillOn(c, multi) {
    c.save();
    c.beginPath();
    for (const polygon of multi) {
      const outer = polygon[0];
      if (!outer || outer.length === 0) continue;
      c.moveTo(outer[0][0], outer[0][1]);
      for (let i = 1; i < outer.length; i++) {
        c.lineTo(outer[i][0], outer[i][1]);
      }
      c.closePath();
    }
    c.fill();
    c.restore();
  }
  function drawMultiPolygonStrokeOn(c, multi, color = '#222', width = 2) {
    c.save();
    c.setLineDash([]);
    c.strokeStyle = color;
    c.lineWidth = width;
    for (const polygon of multi) {
      const outer = polygon[0];
      if (!outer || outer.length === 0) continue;
      c.beginPath();
      c.moveTo(outer[0][0], outer[0][1]);
      for (let i = 1; i < outer.length; i++) {
        c.lineTo(outer[i][0], outer[i][1]);
      }
      c.closePath();
      c.stroke();
    }
    c.restore();
  }

  // 그룹 렌더(내부 경계선을 임시 캔버스로 지웠다가 겉 윤곽선만 그림)
  function renderGroup(g) {
    const children = g.children.map(id => getObj(id)).filter(Boolean);
    children.forEach(o => fillShapeOn(ctx, o));

    if (!GROUP_HIDE_INNER_STROKES) {
      children.forEach(o => strokeShapeOn(ctx, o));
      return;
    }

    // 1) 오프로 자식 스트로크를 먼저 모두 그림
    const off = document.createElement('canvas');
    off.width = canvas.width;
    off.height = canvas.height;
    const octx = off.getContext('2d');
    children.forEach(o => strokeShapeOn(octx, o));

    // 2) 그룹의 합집합 영역을 잘라내기(destination-out) → 내부 윤곽 삭제
    if (!pcLib) return;
    const multi = groupToPolygons(g, pcLib);
    octx.save();
    octx.globalCompositeOperation = 'destination-out';
    octx.fillStyle = '#000';
    drawMultiPolygonFillOn(octx, multi);
    octx.restore();

    // 3) 남은(겉부분만 남은) 스트로크를 본 캔버스에 합성
    ctx.drawImage(off, 0, 0);

    // 4) 마지막으로 합집합 외곽선을 굵게 한 번 더
    const outlineColor = children[0]?.stroke ?? '#222';
    const outlineWidth = Math.max(2, children[0]?.lineWidth ?? 2);
    drawMultiPolygonStrokeOn(ctx, multi, outlineColor, outlineWidth);
  }

  // 메인 렌더 루틴
  function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawGrid();

    // 그룹의 자식은 개별 렌더에서 제외(겹침 방지)
    const groupedIds = new Set();
    state.objects.forEach(o => {
      if (o && o.kind === 'group') o.children.forEach(id => groupedIds.add(id));
    });

    // 1) 그룹에 속하지 않는 개별 도형 먼저
    for (const obj of state.objects) {
      if (!obj || obj.kind === 'group') continue;
      if (!groupedIds.has(obj.id)) obj.draw();
    }

    // 2) 그룹 렌더(내부선 제거/겉윤곽 강조)
    for (const obj of state.objects) {
      if (obj && obj.kind === 'group') renderGroup(obj);
    }

    // 3) 선택 외곽선(핸들 포함)
    for (const id of state.selection) {
      const obj = getObj(id);
      if (!obj) continue;
      obj.drawSelectedOutline();
    }

    // 4) 라인(펜) 모드: 점/미리보기 선
    if (state.tool === 'line' && state.tracing && state.tracePoints.length > 0) {
      ctx.save();
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#ff9800';
      const pts = state.tracePoints;
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
      ctx.stroke();
      ctx.fillStyle = '#ff9800';
      pts.forEach(p => { ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, Math.PI * 2); ctx.fill(); });
      const f = pts[0]; ctx.beginPath(); ctx.arc(f.x, f.y, 10, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
    }

    // 5) 도형 생성(드래그 상자) 미리보기
    if (state.creating) {
      const { type, start, end } = state.creating;
      const x1 = Math.min(start.x, end.x), y1 = Math.min(start.y, end.y);
      const x2 = Math.max(start.x, end.x), y2 = Math.max(start.y, end.y);
      const w = x2 - x1, h = y2 - y1;

      ctx.save();
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);
      ctx.strokeStyle = '#2563eb';

      if (type === 'rect') {
        ctx.strokeRect(x1, y1, w, h);
      }
      else if (type === 'tri') {
        ctx.beginPath();
        ctx.moveTo(x1 + w / 2, y1);
        ctx.lineTo(x2, y2);
        ctx.lineTo(x1, y2);
        ctx.closePath();
        ctx.stroke();
      }
      else if (type === 'circle') {
        ctx.beginPath();
        ctx.ellipse(x1 + w / 2, y1 + h / 2, Math.abs(w / 2), Math.abs(h / 2), 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      else if (type === 'lshape') {
        const tH = Math.min(w, h) * 0.4;
        const tV = Math.min(w, h) * 0.4;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y1);
        ctx.lineTo(x2, y1 + tH);
        ctx.lineTo(x1 + tV, y1 + tH);
        ctx.lineTo(x1 + tV, y2);
        ctx.lineTo(x1, y2);
        ctx.closePath();
        ctx.stroke();
      }
      else if (type === 'cshape') {
        const tH = Math.min(w, h) * 0.3;
        const tV = Math.min(w, h) * 0.3;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y1);
        ctx.lineTo(x2, y1 + tH);
        ctx.lineTo(x1 + tV, y1 + tH);
        ctx.lineTo(x1 + tV, y2 - tH);
        ctx.lineTo(x2, y2 - tH);
        ctx.lineTo(x2, y2);
        ctx.lineTo(x1, y2);
        ctx.closePath();
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  /* =========================================================
   * [세션 5] 핸들/히트 테스트/커서
   *  - 리사이즈/회전/두께 조절 핸들 좌표 계산
   *  - 핸들/도형 히트 판정
   * =======================================================*/

  // 선택 시 그려질 조작 핸들 집합 생성
  function getHandles(obj) {
    // 그룹의 경우: 회전은 bbox 위쪽 중앙 기준, 리사이즈는 bbox 8방향
    if (obj.kind === 'group') {
      const { x, y, w, h } = obj.bbox();
      const corners = [
        { x: x, y: y },
        { x: x + w, y: y },
        { x: x + w, y: y + h },
        { x: x, y: y + h },
      ];
      const [nw, ne, se, sw] = corners;
      const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
      const n = mid(nw, ne), e = mid(ne, se), s = mid(se, sw), wpt = mid(sw, nw);
      const rx = n.x, ry = n.y - ROTATE_HANDLE_OFFSET;
      return [
        { x: nw.x, y: nw.y, code: 'nw', cursor: 'nwse-resize' },
        { x: n.x, y: n.y, code: 'n', cursor: 'ns-resize' },
        { x: ne.x, y: ne.y, code: 'ne', cursor: 'nesw-resize' },
        { x: e.x, y: e.y, code: 'e', cursor: 'ew-resize' },
        { x: se.x, y: se.y, code: 'se', cursor: 'nwse-resize' },
        { x: s.x, y: s.y, code: 's', cursor: 'ns-resize' },
        { x: sw.x, y: sw.y, code: 'sw', cursor: 'nesw-resize' },
        { x: wpt.x, y: wpt.y, code: 'w', cursor: 'ew-resize' },
        { x: rx, y: ry, code: 'rot', cursor: 'grab' },
      ];
    }

    // 일반 도형: 도형 회전에 맞춘 8방향 핸들 + 회전 핸들
    const corners = [
      { x: obj.x, y: obj.y },
      { x: obj.x + obj.w, y: obj.y },
      { x: obj.x + obj.w, y: obj.y + obj.h },
      { x: obj.x, y: obj.y + obj.h },
    ].map(p => rotatePoint(p.x, p.y, obj.cx, obj.cy, obj.angle));
    const [nw, ne, se, sw] = [corners[0], corners[1], corners[2], corners[3]];
    const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
    const n = mid(nw, ne), e = mid(ne, se), s = mid(se, sw), w = mid(sw, nw);
    const dir = { x: n.x - obj.cx, y: n.y - obj.cy };
    const len = Math.hypot(dir.x, dir.y) || 1;
    const rx = n.x + dir.x / len * ROTATE_HANDLE_OFFSET;
    const ry = n.y + dir.y / len * ROTATE_HANDLE_OFFSET;

    const hs = [
      { x: nw.x, y: nw.y, code: 'nw', cursor: 'nwse-resize' },
      { x: n.x, y: n.y, code: 'n', cursor: 'ns-resize' },
      { x: ne.x, y: ne.y, code: 'ne', cursor: 'nesw-resize' },
      { x: e.x, y: e.y, code: 'e', cursor: 'ew-resize' },
      { x: se.x, y: se.y, code: 'se', cursor: 'nwse-resize' },
      { x: s.x, y: s.y, code: 's', cursor: 'ns-resize' },
      { x: sw.x, y: sw.y, code: 'sw', cursor: 'nesw-resize' },
      { x: w.x, y: w.y, code: 'w', cursor: 'ew-resize' },
      { x: rx, y: ry, code: 'rot', cursor: 'grab' },
    ];

    // L/C 모양엔 두께 조절 핸들 2개 추가(세로/가로 띠 두께)
    if (obj.type === 'lshape' || obj.type === 'cshape') {
      const vLocal = { x: -obj.w / 2 + (obj.tV ?? Math.min(obj.w, obj.h) * 0.35), y: 0 };
      const vWorld = rotatePoint(obj.cx + vLocal.x, obj.cy + vLocal.y, obj.cx, obj.cy, obj.angle);
      const hLocal = { x: 0, y: -obj.h / 2 + (obj.tH ?? Math.min(obj.w, obj.h) * 0.35) };
      const hWorld = rotatePoint(obj.cx + hLocal.x, obj.cy + hLocal.y, obj.cx, obj.cy, obj.angle);
      hs.push({ x: vWorld.x, y: vWorld.y, code: 'thickV', cursor: 'ew-resize' });
      hs.push({ x: hWorld.x, y: hWorld.y, code: 'thickH', cursor: 'ns-resize' });
    }

    return hs;
  }

  // 핸들 렌더(선택 1개일 때만)
  function drawHandles(obj) {
    if (state.selection.size !== 1) return;
    const handles = getHandles(obj);
    ctx.save();
    for (const h of handles) {
      let stroke = '#00bcd4';
      if (h.code === 'rot') stroke = '#ff5722';
      if (h.code === 'thickV') stroke = '#8b5cf6';
      if (h.code === 'thickH') stroke = '#10b981';
      ctx.fillStyle = '#fff'; ctx.strokeStyle = stroke; ctx.lineWidth = 1.2;
      ctx.beginPath();
      if (h.code === 'rot') ctx.arc(h.x, h.y, 6, 0, Math.PI * 2);
      else ctx.rect(h.x - HANDLE_SIZE / 2, h.y - HANDLE_SIZE / 2, HANDLE_SIZE, HANDLE_SIZE);
      ctx.fill(); ctx.stroke();
    }
    ctx.restore();
  }

  // 마우스 좌표 근방에서 잡힌 핸들 판정
  function hitHandle(obj, mx, my) {
    const handles = getHandles(obj);
    const half = HANDLE_SIZE / 2 + HIT_PAD;
    for (const h of handles) {
      if (h.code === 'rot') {
        if (Math.hypot(mx - h.x, my - h.y) <= (half + 2)) return h;
      } else {
        if (pointInRect(mx, my, h.x - half, h.y - half, half * 2, half * 2)) return h;
      }
    }
    return null;
  }

  /* =========================================================
   * [세션 6] UI 이벤트: 툴 전환/스냅/그리드
   * =======================================================*/

  function setTool(t) {
    state.tool = t;
    setActiveToolButton(t);
    setStatus(`툴: ${t}${SHAPE_TOOLS.has(t) ? '' : ''}`);
  }
  // 스냅 토글
  chkSnap?.addEventListener('change', () => state.snap = chkSnap.checked);
  // 그리드 크기 변경
  gridSizeInput?.addEventListener('change', () => {
    const v = parseInt(gridSizeInput.value || '10', 10);
    state.gridSize = Math.floor(Math.max(4, v));
    render();
  });

  // 마우스 좌표 변환(캔버스 CSS스케일 고려)
  function getMousePos(evt) {
    const r = canvas.getBoundingClientRect();
    const x = (evt.clientX - r.left) * (canvas.width / r.width);
    const y = (evt.clientY - r.top) * (canvas.height / r.height);
    return { x, y };
  }

  // 최상단부터 역순으로 도형/그룹 히트 테스트
  function hitTest(x, y, ignoreIds = null) {
    for (let i = state.objects.length - 1; i >= 0; i--) {
      const obj = state.objects[i];
      if (!obj) continue;
      if (ignoreIds && ignoreIds.has(obj.id)) continue;
      if (obj.kind === 'group') {
        const b = obj.bbox();
        if (pointInRect(x, y, b.x, b.y, b.w, b.h)) return obj;
      } else {
        if (obj.hit && obj.hit(x, y)) return obj;
      }
    }
    return null;
  }
  // Ctrl(또는 Cmd) 클릭 시: 현재 선택을 우선 무시하고 비선택된 객체를 먼저 잡도록 보정
  function hitTestPreferUnselected(x, y) {
    const target1 = hitTest(x, y, state.selection);
    if (target1) return target1;
    return hitTest(x, y, null);
  }

  /* =========================================================
   * [세션 7] 리사이즈/회전 로직(개별/그룹/L/C 두께 조절)
   * =======================================================*/

  // 리사이즈 적용(핸들 코드에 따라 bbox 조정 / poly 점 스케일 / L/C 두께 조절)
  function applyResize(obj, handleCode, startBBox, startMouse, curMouse) {
    // 7-1) L/C 두께 핸들(thickV/thickH)
    if ((handleCode === 'thickV' || handleCode === 'thickH') && (obj.type === 'lshape' || obj.type === 'cshape')) {
      const cx = obj.cx, cy = obj.cy;
      const sm = invRotatePoint(startMouse.x, startMouse.y, cx, cy, obj.angle);
      const cm = invRotatePoint(snap(curMouse.x), snap(curMouse.y), cx, cy, obj.angle);

      let sens = THICK_SENS;            // 기본 감도
      if (state.keymods.shift) sens *= THICK_FINE;   // Shift: 미세
      if (state.keymods.alt) sens *= THICK_COARSE; // Alt: 거칠게

      const baseTV = state.resizeStartThick.tV ?? (obj.tV ?? Math.min(obj.w, obj.h) * 0.35);
      const baseTH = state.resizeStartThick.tH ?? (obj.tH ?? Math.min(obj.w, obj.h) * 0.35);

      if (handleCode === 'thickV') {
        let next = baseTV + (cm.x - sm.x) * sens;
        const step = state.snap ? Math.max(1, state.gridSize) : THICK_STEP;
        next = roundTo(next, step);
        obj.tV = Math.max(5, Math.min(obj.w - 5, next));
      } else {
        let next = baseTH + (cm.y - sm.y) * sens;
        const step = state.snap ? Math.max(1, state.gridSize) : THICK_STEP;
        next = roundTo(next, step);
        obj.tH = Math.max(5, Math.min(obj.h - 5, next));
      }
      return;
    }

    // 7-2) 그룹 리사이즈(스냅샷 기준으로 상대 스케일 적용)
    if (obj.kind === 'group') {
      if (!state.groupResizeSnapshot) return;
      const ob = startBBox;
      let lx = ob.x, ly = ob.y, lw = ob.w, lh = ob.h;

      const dx = snap(curMouse.x) - startMouse.x;
      const dy = snap(curMouse.y) - startMouse.y;

      if (handleCode.includes('n')) { ly += dy; lh -= dy; }
      if (handleCode.includes('s')) { lh += dy; }
      if (handleCode.includes('w')) { lx += dx; lw -= dx; }
      if (handleCode.includes('e')) { lw += dx; }

      lw = Math.max(10, lw); lh = Math.max(10, lh);

      const sx = lw / (ob.w || 1);   // 가로 스케일 비
      const sy = lh / (ob.h || 1);   // 세로 스케일 비

      state.groupResizeSnapshot.forEach(s => {
        const child = getObj(s.id);
        if (!child) return;

        if (s.type === 'poly' && s.points) {
          // poly는 각 점을 bbox 비율로 스케일
          child.meta.points = s.points.map(p => ({
            x: lx + (p.x - ob.x) * sx,
            y: ly + (p.y - ob.y) * sy
          }));
          const xs = child.meta.points.map(p => p.x), ys = child.meta.points.map(p => p.y);
          child.x = Math.min(...xs); child.y = Math.min(...ys);
          child.w = Math.max(...xs) - child.x; child.h = Math.max(...ys) - child.y;
          child.angle = s.angle;
        } else {
          // 그 외 도형은 중심/크기만 스케일
          const cxNew = lx + (s.cx - ob.x) * sx;
          const cyNew = ly + (s.cy - ob.y) * sy;
          const wNew = Math.max(1, s.w * sx);
          const hNew = Math.max(1, s.h * sy);
          child.x = cxNew - wNew / 2;
          child.y = cyNew - hNew / 2;
          child.w = wNew; child.h = hNew;
          child.angle = s.angle;

          // L/C 두께도 축 비율에 맞춰 스케일
          if (child.type === 'lshape' || child.type === 'cshape') {
            if (typeof s.tV === 'number') child.tV = Math.max(1, s.tV * sx);
            if (typeof s.tH === 'number') child.tH = Math.max(1, s.tH * sy);
          }
        }
      });
      return;
    }

    // 7-3) 개별 도형 리사이즈(회전 보정 좌표계에서 계산)
    const cx = obj.cx, cy = obj.cy;
    const sm = invRotatePoint(startMouse.x, startMouse.y, cx, cy, obj.angle);
    const cm = invRotatePoint(snap(curMouse.x), snap(curMouse.y), cx, cy, obj.angle);

    let { x, y, w, h } = startBBox;
    const rNW = invRotatePoint(x, y, cx, cy, obj.angle);
    const rSE = invRotatePoint(x + w, y + h, cx, cy, obj.angle);
    let lx2 = rNW.x, ly2 = rNW.y, lw2 = rSE.x - rNW.x, lh2 = rSE.y - rNW.y;

    const dx2 = cm.x - sm.x;
    const dy2 = cm.y - sm.y;

    if (handleCode.includes('n')) { ly2 += dy2; lh2 -= dy2; }
    if (handleCode.includes('s')) { lh2 += dy2; }
    if (handleCode.includes('w')) { lx2 += dx2; lw2 -= dx2; }
    if (handleCode.includes('e')) { lw2 += dx2; }

    lw2 = Math.max(10, lw2); lh2 = Math.max(10, lh2);

    const nwc = rotatePoint(lx2 + lw2 / 2, ly2 + lh2 / 2, cx, cy, obj.angle);
    obj.x = nwc.x - lw2 / 2; obj.y = nwc.y - lh2 / 2;
    obj.w = lw2; obj.h = lh2;

    // poly의 경우 점들을 bbox 비율로 스케일
    if (obj.type === 'poly' && state.resizeRefPoints) {
      const ob = startBBox;
      const obLocalNW = invRotatePoint(ob.x, ob.y, cx, cy, obj.angle);
      const obLocalSE = invRotatePoint(ob.x + ob.w, ob.y + ob.h, cx, cy, obj.angle);
      const obW = obLocalSE.x - obLocalNW.x;
      const obH = obLocalSE.y - obLocalNW.y;
      const sx = lw2 / (obW || 1);
      const sy = lh2 / (obH || 1);

      const newPts = state.resizeRefPoints.map(p => {
        const pl = invRotatePoint(p.x, p.y, cx, cy, obj.angle);
        const rx = (pl.x - obLocalNW.x) * sx + (lx2);
        const ry = (pl.y - obLocalNW.y) * sy + (ly2);
        const pw = rotatePoint(rx, ry, cx, cy, obj.angle);
        return { x: pw.x, y: pw.y };
      });
      obj.meta.points = newPts;
    }

    // L/C 두께가 박스보다 커지지 않도록 보정
    if (obj.type === 'lshape' || obj.type === 'cshape') {
      obj.tV = Math.max(1, Math.min(obj.w - 1, obj.tV ?? Math.min(obj.w, obj.h) * 0.35));
      obj.tH = Math.max(1, Math.min(obj.h - 1, obj.tH ?? Math.min(obj.w, obj.h) * 0.35));
    }
  }

  // 회전 적용(개별/그룹)
  function applyRotate(obj, anchor, startMouse, curMouse, startAngle) {
    const a1 = Math.atan2(startMouse.y - anchor.y, startMouse.x - anchor.x);
    const a2 = Math.atan2(curMouse.y - anchor.y, curMouse.x - anchor.x);
    const delta = a2 - a1;

    // 그룹 회전: 각 자식의 중심과 각도를 스냅샷 기준으로 회전 적용
    if (obj.kind === 'group') {
      if (!state.groupRotateSnapshot) return;
      state.groupRotateSnapshot.forEach(s => {
        const child = getObj(s.id);
        if (!child) return;

        const rc = rotatePoint(s.cx, s.cy, anchor.x, anchor.y, delta);

        if (s.type === 'poly' && s.points) {
          child.meta.points = s.points.map(p => rotatePoint(p.x, p.y, anchor.x, anchor.y, delta));
          const xs = child.meta.points.map(p => p.x), ys = child.meta.points.map(p => p.y);
          child.x = Math.min(...xs); child.y = Math.min(...ys);
          child.w = Math.max(...xs) - child.x; child.h = Math.max(...ys) - child.y;
          child.angle = s.angle;
        } else {
          child.w = s.w; child.h = s.h;
          child.x = rc.x - child.w / 2;
          child.y = rc.y - child.h / 2;
          child.angle = (s.angle || 0) + delta;
        }
      });
      return;
    }

    // 개별 회전: 단순 각도 누적
    obj.angle = startAngle + delta;
  }

  /* =========================================================
   * [세션 8] 마우스/키보드 이벤트 — 그리기/선택/이동/리사이즈/회전
   * =======================================================*/

  // 마우스 다운: 도형 생성/라인 점찍기/핸들 잡기/선택 토글/드래그 준비
  canvas.addEventListener('mousedown', (e) => {
    const m = getMousePos(e);
    state.lastMouse = m;

    // 8-1) 도형 생성 툴: 드래그 박스 시작
    if (SHAPE_TOOLS.has(state.tool)) {
      state.creating = {
        type: state.tool,
        start: { x: snap(m.x), y: snap(m.y) },
        end: { x: snap(m.x), y: snap(m.y) }
      };
      setStatus('drag create');
      return;
    }

    // 8-2) 라인(펜) 모드: 점 찍기 / 첫점 근접 더블클릭 동작(닫기)
    if (state.tool === 'line') {
      if (!state.tracing) { state.tracing = true; state.tracePoints = []; }
      const pt = { x: snap(m.x), y: snap(m.y) };
      const first = state.tracePoints[0];
      if (first && Math.hypot(pt.x - first.x, pt.y - first.y) <= 10 && state.tracePoints.length >= 3) {
        finishPen(); return;
      }
      state.tracePoints.push(pt);
      render(); return;
    }

    // 8-3) 선택 1개일 때: 핸들 히트 → 리사이즈/회전 시작
    if (state.selection.size === 1) {
      const selObj = getObj([...state.selection][0]);
      const h = hitHandle(selObj, m.x, m.y);
      if (h) {
        if (h.code === 'rot') {
          // 회전 시작
          state.rotating = true;
          state.rotateTargetId = selObj.id;
          state.rotateStartMouse = { x: m.x, y: m.y };

          if (selObj.kind === 'group') {
            // 그룹 회전 앵커는 그룹 bbox의 중심
            const { cx, cy } = groupCenter(selObj);
            state.rotateAnchor = { x: cx, y: cy };

            // 그룹 회전 스냅샷(각 자식의 중심/크기/각도/점목록)
            state.groupRotateSnapshot = selObj.children.map(id => {
              const o = getObj(id);
              return {
                id: o.id, type: o.type,
                cx: o.x + o.w / 2, cy: o.y + o.h / 2,
                w: o.w, h: o.h,
                angle: o.angle || 0,
                points: (o.type === 'poly') ? o.meta.points.map(p => ({ x: p.x, y: p.y })) : null
              };
            });
            state.rotateStartAngle = 0;
          } else {
            state.rotateAnchor = { x: selObj.cx, y: selObj.cy };
            state.rotateStartAngle = selObj.angle || 0;
            state.groupRotateSnapshot = null;
          }
          canvas.style.cursor = 'grabbing';
          return;
        } else {
          // 리사이즈 시작
          state.resizing = true;
          state.activeHandle = h.code;
          state.resizeTargetId = selObj.id;
          state.resizeStartMouse = { x: snap(m.x), y: snap(m.y) };
          state.resizeStartBBox = { ...selObj.bbox() };
          state.resizeRefPoints = selObj.type === 'poly' ? selObj.meta.points.map(p => ({ x: p.x, y: p.y })) : null;

          if (selObj.kind === 'group') {
            // 그룹 리사이즈 스냅샷(자식별 중심/크기/각도/점/두께)
            state.groupResizeSnapshot = selObj.children.map(id => {
              const o = getObj(id);
              return {
                id: o.id, type: o.type,
                cx: o.x + o.w / 2, cy: o.y + o.h / 2,
                w: o.w, h: o.h,
                angle: o.angle || 0,
                points: (o.type === 'poly') ? o.meta.points.map(p => ({ x: p.x, y: p.y })) : null,
                tH: (o.type === 'lshape' || o.type === 'cshape') ? o.tH : undefined,
                tV: (o.type === 'lshape' || o.type === 'cshape') ? o.tV : undefined,
              };
            });
          } else {
            state.groupResizeSnapshot = null;
          }

          // L/C 두께 핸들 시작값 저장
          if ((h.code === 'thickV' || h.code === 'thickH') && (selObj.type === 'lshape' || selObj.type === 'cshape')) {
            state.resizeStartThick.tV = selObj.tV ?? Math.min(selObj.w, selObj.h) * 0.35;
            state.resizeStartThick.tH = selObj.tH ?? Math.min(selObj.w, selObj.h) * 0.35;
          } else {
            state.resizeStartThick.tV = null;
            state.resizeStartThick.tH = null;
          }

          canvas.style.cursor = h.cursor;
          return;
        }
      }
    }

    // 8-4) 빈 곳/도형 클릭: 선택 및 드래그 준비
    let target;
    if (e.ctrlKey) target = hitTestPreferUnselected(m.x, m.y);
    else target = hitTest(m.x, m.y);

    if (state.tool === 'select') {
      if (target) {
        if (e.ctrlKey) {
          // Ctrl: 토글 선택
          if (state.selection.has(target.id)) state.selection.delete(target.id);
          else state.selection.add(target.id);
          state.dragging = false; state.maybeDragging = false;
        } else {
          // 단일 선택 + 드래그 준비
          state.selection.clear();
          state.selection.add(target.id);
          state.maybeDragging = true;
          state.dragging = false;
          state.dragStart = { x: snap(m.x), y: snap(m.y) };
        }
      } else {
        if (!e.ctrlKey) state.selection.clear();
      }
      render(); return;
    }
  });

  // 마우스 무브: 생성 미리보기/회전/리사이즈/드래그/커서/상태표시
  canvas.addEventListener('mousemove', (e) => {
    const m = getMousePos(e);
    state.lastMouse = m;

    // 8-5) 생성 박스 갱신
    if (state.creating) {
      state.creating.end = { x: snap(m.x), y: snap(m.y) };
      render();
      return;
    }

    // 8-6) 회전 중
    if (state.rotating) {
      const obj = getObj(state.rotateTargetId);
      if (obj) {
        applyRotate(obj, state.rotateAnchor, state.rotateStartMouse, m, state.rotateStartAngle);
        setStatus(`回転: ${obj.kind === 'group' ? '' : Math.round(rad2deg(obj.angle))}°`);
        render();
      }
      return;
    }

    // 8-7) 리사이즈 중
    if (state.resizing) {
      const obj = getObj(state.resizeTargetId);
      if (obj) {
        applyResize(obj, state.activeHandle, state.resizeStartBBox, state.resizeStartMouse, m);
        render();
      }
      return;
    }

    // 8-8) 드래그 시작 임계치 체크
    if (state.maybeDragging && state.selection.size > 0) {
      const dx0 = snap(m.x) - state.dragStart.x;
      const dy0 = snap(m.y) - state.dragStart.y;
      if (Math.hypot(dx0, dy0) >= DRAG_START_THRESHOLD) {
        state.dragging = true;
        state.maybeDragging = false;
      }
    }

    // 8-9) 드래그 중: 선택된 모든 도형 이동
    if (state.dragging && state.selection.size > 0) {
      const dx = snap(m.x) - state.dragStart.x;
      const dy = snap(m.y) - state.dragStart.y;
      if (dx !== 0 || dy !== 0) {
        for (const id of state.selection) {
          const obj = getObj(id); if (obj) obj.moveBy(dx, dy);
        }
        state.dragStart = { x: snap(m.x), y: snap(m.y) };
        render();
      }
      return;
    }

    // 8-10) 커서/상태 텍스트 업데이트
    canvas.style.cursor = 'crosshair';
    if (state.selection.size === 1) {
      const selObj = getObj([...state.selection][0]);
      if (selObj) {
        const h = hitHandle(selObj, m.x, m.y);
        if (h) { canvas.style.cursor = h.code === 'rot' ? 'grab' : h.cursor; setStatus(h.code); return; }
      }
    }
    const hover = hitTest(m.x, m.y);
    if (hover) { canvas.style.cursor = 'move'; setStatus('移動可能'); }
    else { setStatus(`x:${Math.round(m.x)} y:${Math.round(m.y)} ${state.snap ? '' : ''}`); }
  });

  // 마우스 업: 생성 완료/모드 리셋
  canvas.addEventListener('mouseup', (e) => {
    // 8-11) 생성 종료 → 실제 도형 push + select 전환
    if (state.creating) {
      const { type, start } = state.creating;
      const m = getMousePos(e);
      const end = { x: snap(m.x), y: snap(m.y) };
      const x1 = Math.min(start.x, end.x), y1 = Math.min(start.y, end.y);
      const x2 = Math.max(start.x, end.x), y2 = Math.max(start.y, end.y);
      const w = Math.max(1, x2 - x1), h = Math.max(1, y2 - y1);

      if (w >= 3 && h >= 3) {
        let obj = null;
        if (type === 'rect') obj = new Rect({ x: x1, y: y1, w, h });
        if (type === 'tri') obj = new Tri({ x: x1, y: y1, w, h });
        if (type === 'circle') obj = new Circle({ x: x1, y: y1, w, h });
        if (type === 'lshape') obj = new LShape({ x: x1, y: y1, w, h });
        if (type === 'cshape') obj = new CShape({ x: x1, y: y1, w, h });
        if (obj) {
          state.objects.push(obj);
          state.selection.clear();
          state.selection.add(obj.id);
        }
      }
      state.creating = null;

      state.tool = 'select';
      setActiveToolButton('select');
      canvas.style.cursor = 'crosshair';
      setStatus('選択モード');
      render();
    }

    // 조작 모드 리셋
    state.dragging = false;
    state.maybeDragging = false;
    state.resizing = false;
    state.rotating = false;
    state.activeHandle = null;
    state.resizeTargetId = null;
    state.rotateTargetId = null;
    state.resizeRefPoints = null;
    state.groupResizeSnapshot = null;
    state.groupRotateSnapshot = null;
    state.resizeStartThick.tV = null;
    state.resizeStartThick.tH = null;
    canvas.style.cursor = 'crosshair';
  });

  // 더블클릭: 라인(펜) 모드에서 폴리곤 확정(3점 이상)
  canvas.addEventListener('dblclick', () => {
    if (state.tool === 'line' && state.tracing && state.tracePoints.length >= 3) { finishPen(); }
  });

  // 키보드: Delete/Enter/Escape/Shift/Alt
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Delete') { deleteSelection(); }
    if (e.key === 'Enter') {
      if (state.tool === 'line' && state.tracing && state.tracePoints.length >= 3) { finishPen(); }
    }
    if (e.key === 'Escape') {
      if (state.tool === 'line' && state.tracing) cancelPen();
      if (state.creating) { state.creating = null; render(); }
    }
    if (e.key === 'Shift') state.keymods.shift = true;
    if (e.key === 'Alt') state.keymods.alt = true;
  });
  window.addEventListener('keyup', (e) => {
    if (e.key === 'Shift') state.keymods.shift = false;
    if (e.key === 'Alt') state.keymods.alt = false;
  });

  /* =========================================================
   * [세션 9] 타원(ellipse) 캡 분할 + 클릭 시 해당 캡 영역에 이미지 클립 그리기
   *  - ellipse가 다른 도형/그룹과 겹치는 부분을 캡(분할된 영역)으로 취급
   *  - 클릭한 캡에만 이미지 1장 그리기(clip)
   * =======================================================*/

  // 클릭 시: 타원 도형 위에서만 캡 선택 → 이미지 그려 넣기 예시
  canvas.addEventListener('click', async (e) => {
    if (state.dragging || state.resizing || state.rotating || state.creating) return;
    const m = getMousePos(e);
    const hit = hitTest(m.x, m.y);
    if (!hit || hit.type !== 'circle') return;

    if (ELLIPSE_CLIP_MODE === 'whole') {
      // 분할 없이 타원 전체 외곽 링으로만 클립
      const ring = ellipseOuterRing(hit);
      if (!ring) return;

      const img = new Image();
      img.onload = () => {
        clipPolygonAndDraw(ctx, ring, img, 'cover');  // 한 장으로만 그리기
        // strokeRing(ctx, ring, '#ff9800', 2);       // 필요하면 강조선
      };
      img.src = 'your-image-url.png';
      return;
    }

    // (옵션) 기존: 캡 분할 방식 유지하고 싶을 때
    await ensurePc();
    const capRing = pickEllipseCapAtPoint(hit, m.x, m.y, pcLib);
    if (!capRing) return;

    const img = new Image();
    img.onload = () => {
      clipPolygonAndDraw(ctx, capRing, img, 'cover');
    };
    img.src = 'your-image-url.png';
  });

  /* =========================================================
   * [세션 10] 선택 삭제/그룹화/그룹 해제
   * =======================================================*/

  // 선택 삭제(그룹이면 자식까지 제거 / 자식 빠진 그룹은 자동 제거)
  function deleteSelection() {
    if (state.selection.size === 0) return;
    const toDelete = new Set();
    for (const id of state.selection) {
      const o = getObj(id);
      if (!o) continue;
      if (o.kind === 'group') {
        toDelete.add(o.id);
        o.children.forEach(cid => toDelete.add(cid));
      } else {
        toDelete.add(o.id);
      }
    }
    state.objects = state.objects
      .map(o => {
        if (!o) return null;
        if (toDelete.has(o.id)) return null;
        if (o.kind === 'group') {
          o.children = o.children.filter(cid => !toDelete.has(cid));
          if (o.children.length < 2) return null;
        }
        return o;
      })
      .filter(Boolean);
    state.selection.clear();
    render();
  }
  btnDelete?.addEventListener('click', deleteSelection);

  // 그룹화: 선택된 다수(그룹/도형 섞여도 OK)를 하나의 그룹으로
  btnGroup?.addEventListener('click', () => {
    if (state.selection.size < 2) return;
    const selectedIds = [...state.selection];
    const shapeIds = new Set();
    const groupIds = new Set();
    selectedIds.forEach(id => {
      const o = getObj(id);
      if (!o) return;
      if (o.kind === 'group') {
        groupIds.add(o.id);
        o.children.forEach(cid => shapeIds.add(cid));
      } else {
        shapeIds.add(o.id);
      }
    });
    const finalIds = [...shapeIds];
    if (finalIds.length < 2) return;

    // 기존 그룹 제거 → 새 그룹 생성
    state.objects = state.objects.filter(o => o && !groupIds.has(o.id));
    const g = new Group(finalIds);
    state.objects.push(g);
    state.selection.clear();
    state.selection.add(g.id);
    render();
  });

  // 그룹 해제: 선택된 그룹들을 풀어내기
  btnUngroup?.addEventListener('click', () => {
    const ids = [...state.selection];
    let changed = false;
    ids.forEach(id => {
      const o = getObj(id);
      if (o && o.kind === 'group') {
        state.objects = state.objects.filter(x => x && x.id !== o.id);
        state.selection.delete(id);
        changed = true;
      }
    });
    if (changed) render();
  });

  /* =========================================================
   * [세션 11] 상태 텍스트/펜 도형 완성/취소
   * =======================================================*/

  // 상태 텍스트(좌측 하단 등)
  function setStatus(msg) { statusEl && (statusEl.textContent = msg); }

  // 펜 도형 확정 → Poly 객체로 추가
  function finishPen() {
    const pts = state.tracePoints.slice();
    state.tracing = false; state.tracePoints = [];
    const poly = new Poly(pts);
    state.objects.push(poly);
    state.selection.clear(); state.selection.add(poly.id);
    state.tool = 'select';
    setActiveToolButton('select');
    canvas.style.cursor = 'crosshair';
    setStatus('ペン図形完了＞選択モード切り替え');
    render();
  }
  // 펜 도형 취소
  function cancelPen() {
    state.tracing = false; state.tracePoints = [];
    setStatus('ペンキャンセル'); render();
  }

  /* =========================================================
   * [세션 12] 폴리곤 변환 유틸(연산용)
   *  - 도형을 polygon-clipping의 MultiPolygon 형태로 변환
   *  - 그룹을 자식들 합집합으로 변환
   * =======================================================*/

  function ringSignedArea(ring) {
    let a = 0; for (let i = 0; i < ring.length; i++) { const p = ring[i], q = ring[(i + 1) % ring.length]; a += p.x * q.y - p.y * q.x; }
    return a;
  }
  function ensureCCW(ring) { const arr = ring.slice(); if (ringSignedArea(arr) < 0) arr.reverse(); return arr; }
  function almostEqual(a, b, eps = 1e-6) { return Math.abs(a - b) <= eps; }
  function isClosedRing(ring) {
    if (!ring || ring.length < 2) return false;
    const [x0, y0] = ring[0], [xn, yn] = ring[ring.length - 1];
    return almostEqual(x0, xn) && almostEqual(y0, yn);
  }
  function stripClosure(ring) {
    if (!Array.isArray(ring) || ring.length < 2) return ring;
    return isClosedRing(ring) ? ring.slice(0, ring.length - 1) : ring;
  }

  // 단일 도형을 MultiPolygon([[ring]]) 형태로 변환
  function shapeToPolygon(o) {
    const pts = []; const cx = o.x + o.w / 2, cy = o.y + o.h / 2;
    if (o.type === 'rect') {
      const raw = [{ x: o.x, y: o.y }, { x: o.x + o.w, y: o.y }, { x: o.x + o.w, y: o.y + o.h }, { x: o.x, y: o.y + o.h }];
      raw.forEach(p => pts.push(rotatePoint(p.x, p.y, cx, cy, o.angle || 0)));
    }
    else if (o.type === 'tri') {
      const raw = [{ x: cx, y: o.y }, { x: o.x + o.w, y: o.y + o.h }, { x: o.x, y: o.y + o.h }];
      raw.forEach(p => pts.push(rotatePoint(p.x, p.y, cx, cy, o.angle || 0)));
    }
    else if (o.type === 'circle') {
      // 타원 근사: N각형(기본 48분할)
      const N = 48;
      for (let i = 0; i < N; i++) {
        const t = i / N * Math.PI * 2;
        const px = cx + (o.w / 2) * Math.cos(t);
        const py = cy + (o.h / 2) * Math.sin(t);
        pts.push(rotatePoint(px, py, cx, cy, o.angle || 0));
      }
    }
    else if (o.type === 'lshape' || o.type === 'cshape') {
      // L/C는 로컬 꼭짓점 배열을 회전/이동한 후 world 좌표로 push
      const w = o.w, h = o.h;
      const tH = o.tH ?? Math.min(w, h) * (o.type === 'lshape' ? 0.4 : 0.3);
      const tV = o.tV ?? Math.min(w, h) * (o.type === 'lshape' ? 0.4 : 0.3);
      let raw;
      if (o.type === 'lshape') {
        raw = [
          { x: -w / 2, y: -h / 2 },
          { x: w / 2, y: -h / 2 },
          { x: w / 2, y: -h / 2 + tH },
          { x: -w / 2 + tV, y: -h / 2 + tH },
          { x: -w / 2 + tV, y: h / 2 },
          { x: -w / 2, y: h / 2 },
        ];
      } else {
        raw = [
          { x: -w / 2, y: -h / 2 },
          { x: w / 2, y: -h / 2 },
          { x: w / 2, y: -h / 2 + tH },
          { x: -w / 2 + tV, y: -h / 2 + tH },
          { x: -w / 2 + tV, y: h / 2 - tH },
          { x: w / 2, y: h / 2 - tH },
          { x: w / 2, y: h / 2 },
          { x: -w / 2, y: h / 2 },
        ];
      }
      raw.forEach(lp => {
        const wx = cx + lp.x, wy = cy + lp.y;
        pts.push(rotatePoint(wx, wy, cx, cy, o.angle || 0));
      });
    }
    else if (o.type === 'poly') {
      (o.meta.points || []).forEach(p => pts.push({ x: p.x, y: p.y }));
    }
    const ring = ensureCCW(pts).map(p => [p.x, p.y]);
    return [[ring]];
  }

  // 그룹 → 자식 도형들의 합집합
  function groupToPolygons(g, pc) {
    const polys = g.children.map(id => shapeToPolygon(getObj(id)));
    return pc.union(...polys);
  }

  /* =========================================================
   * [세션 13] 세션 스토리지 임시 저장/복원
   * =======================================================*/

  function saveDraftToSession() {
    const scene = {
      gridSize: state.gridSize,
      snap: state.snap,
      objects: state.objects.map(o => {
        if (o.kind === 'group') {
          return { kind: 'group', id: o.id, children: [...o.children] };
        } else {
          const base = {
            kind: 'shape', id: o.id, type: o.type,
            x: o.x, y: o.y, w: o.w, h: o.h,
            angle: o.angle || 0,
            fill: o.fill, stroke: o.stroke, lineWidth: o.lineWidth,
          };
          if (o.type === 'lshape' || o.type === 'cshape') {
            base.tH = o.tH; base.tV = o.tV;
          }
          if (o.type === 'poly') {
            base.meta = { points: (o.meta.points || []).map(p => ({ x: p.x, y: p.y })) };
          }
          return base;
        }
      })
    };
    sessionStorage.setItem('floorDraft', JSON.stringify(scene));
  }

  function restoreDraftFromSession() {
    const flag = sessionStorage.getItem('restoreOnReturn');
    const raw = sessionStorage.getItem('floorDraft');
    if (!flag || !raw) return false;

    try {
      const scene = JSON.parse(raw);
      state.objects = []; state.selection.clear();
      _id = 1;

      // shape 복원
      scene.objects.filter(o => o.kind === 'shape').forEach(s => {
        let obj = null;
        const common = { x: s.x, y: s.y, w: s.w, h: s.h, fill: s.fill, stroke: s.stroke, lineWidth: s.lineWidth, angle: s.angle };
        if (s.type === 'rect') obj = new Rect(common);
        if (s.type === 'tri') obj = new Tri(common);
        if (s.type === 'circle') obj = new Circle(common);
        if (s.type === 'lshape') obj = new LShape({ ...common, tH: s.tH, tV: s.tV });
        if (s.type === 'cshape') obj = new CShape({ ...common, tH: s.tH, tV: s.tV });
        if (s.type === 'poly') obj = new Poly((s.meta?.points) || [], common);

        if (obj) {
          obj.id = s.id;
          state.objects.push(obj);
        }
      });

      // 그룹 복원
      scene.objects.filter(o => o.kind === 'group').forEach(g => {
        const gobj = new Group(g.children);
        gobj.id = g.id;
        state.objects.push(gobj);
      });

      // 그리드/스냅 복원
      if (typeof scene.gridSize === 'number') state.gridSize = scene.gridSize;
      if (typeof scene.snap === 'boolean') state.snap = scene.snap;
      gridSizeInput && (gridSizeInput.value = String(state.gridSize));
      chkSnap && (chkSnap.checked = state.snap);

      // 1회 사용 후 제거
      sessionStorage.removeItem('restoreOnReturn');

      render();
      return true;
    } catch (e) {
      console.warn('restoreDraftFromSession failed:', e);
      return false;
    }
  }

  /* =========================================================
   * [세션 14] 타원 캡 유틸(분할/선택/클립 그리기)
   *  - ellipseCapsAsRings: 타원을 주변 도형으로 나눈 ‘캡’ 링 집합
   *  - pickEllipseCapAtPoint: 클릭 좌표가 포함된 캡 하나 찾기
   *  - clipPolygonAndDraw: 해당 캡 모양으로 이미지를 잘라 그리기
   * =======================================================*/

  // 배열 ring → Path2D
  function pathFromRing(ring) {
    const p = new Path2D();
    p.moveTo(ring[0][0], ring[0][1]);
    for (let i = 1; i < ring.length; i++) p.lineTo(ring[i][0], ring[i][1]);
    p.closePath();
    return p;
  }

  // 타원 도형을 주변(최상위) 도형들과 boolean difference하여 캡들 추출
  function ellipseCapsAsRings(ellipseObj, pc) {
    const ellipseMP = shapeToPolygon(ellipseObj);

    const neighborMPs = [];
    const grouped = new Set();
    state.objects.forEach(o => { if (o?.kind === 'group') o.children.forEach(id => grouped.add(id)); });
    const topLevel = state.objects.filter(o => o && (o.kind === 'group' || !grouped.has(o.id)));

    // 자신 제외한 최상위 요소를 이웃으로 수집
    topLevel.forEach(o => {
      if (o.kind !== 'group' && o.id === ellipseObj.id) return;
      neighborMPs.push(o.kind === 'group' ? groupToPolygons(o, pc) : shapeToPolygon(o));
    });

    // 이웃들의 합집합
    const neighborsUnion = neighborMPs.length ? pc.union(...neighborMPs) : null;
    // 타원 - 이웃합집합 = 캡(분할된 타원 조각들)
    const capsMP = neighborsUnion ? pc.difference(ellipseMP, neighborsUnion) : ellipseMP;

    // 외곽 링만 추출(CCW 보정, 마지막 점 중복 제거)
    const rings = [];
    capsMP.forEach(poly => {
      const outer = poly?.[0];
      if (outer && outer.length) {
        const ring = stripClosure(outer).map(([x, y]) => [x, y]);
        let area = 0; for (let i = 0; i < ring.length; i++) { const [x1, y1] = ring[i], [x2, y2] = ring[(i + 1) % ring.length]; area += x1 * y2 - y1 * x2; }
        if (area < 0) ring.reverse();
        rings.push(ring);
      }
    });
    return rings;
  }

  // 클릭 좌표가 포함된 타원 캡 하나 선택
  function pickEllipseCapAtPoint(ellipseObj, px, py, pc) {
    const rings = ellipseCapsAsRings(ellipseObj, pc);
    for (const ring of rings) {
      const p = pathFromRing(ring);
      if (ctx.isPointInPath(p, px, py)) return ring;
    }
    return null;
  }

  // 디버그용: 링 외곽선 강조
  function strokeRing(ctx, ring, color = '#00bcd4', width = 2) {
    const p = pathFromRing(ring);
    ctx.save(); ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke(p); ctx.restore();
  }

  // 링(다각형) 경계로 clip 후 이미지 그리기(object-fit 유사 옵션)
  function clipPolygonAndDraw(context, ring, img, objectFit = 'cover') {
    const p = pathFromRing(ring);
    const bb = (() => {
      const xs = ring.map(([x]) => x), ys = ring.map(([, y]) => y);
      const x = Math.min(...xs), y = Math.min(...ys);
      const w = Math.max(...xs) - x, h = Math.max(...ys) - y;
      return { x, y, w, h };
    })();

    // 타원 도형의 외곽 링만 반환 (MultiPolygon -> 첫 polygon의 outer ring)
    function ellipseOuterRing(ellipseObj) {
      const mp = shapeToPolygon(ellipseObj);   // [[ [ring] ]]
      if (!mp || !mp.length || !mp[0] || !mp[0][0]) return null;
      const outer = mp[0][0];                  // [[x,y], ...]
      const ring = stripClosure(outer).map(([x, y]) => [x, y]); // 마지막 중복점 제거
      // 시계(CCW) 보정
      let area = 0;
      for (let i = 0; i < ring.length; i++) {
        const [x1, y1] = ring[i], [x2, y2] = ring[(i + 1) % ring.length];
        area += x1 * y2 - y1 * x2;
      }
      if (area < 0) ring.reverse();
      return ring;
    }


    context.save();
    context.clip(p);

    // 이미지 비율 유지하며 cover/contain 유사 동작
    let dw = bb.w, dh = bb.h, dx = bb.x, dy = bb.y;
    const ir = img.width / img.height;
    const br = bb.w / bb.h;

    if (objectFit === 'cover') {
      if (ir > br) { // 이미지가 더 가로로 길다 → 높이에 맞추고 좌우 여백 잘라냄
        dh = bb.h;
        dw = dh * ir;
        dx = bb.x + (bb.w - dw) / 2;
        dy = bb.y;
      } else {
        dw = bb.w;
        dh = dw / ir;
        dx = bb.x;
        dy = bb.y + (bb.h - dh) / 2;
      }
    } else if (objectFit === 'contain') {
      if (ir > br) {
        dw = bb.w;
        dh = dw / ir;
        dx = bb.x;
        dy = bb.y + (bb.h - dh) / 2;
      } else {
        dh = bb.h;
        dw = dh * ir;
        dx = bb.x + (bb.w - dw) / 2;
        dy = bb.y;
      }
    }

    context.drawImage(img, dx, dy, dw, dh);
    context.restore();
  }


  /* =========================================================
   * [세션 15] 저장 버튼(폴리곤 JSON + 미리보기 PNG) + 페이지 이동
   *  - 최상위 요소(그룹은 합집합 윤곽으로)만 JSON/PNG로 내보냄
   *  - sessionStorage에 복귀 플래그 설정 후 building_img.html로 이동
   * =======================================================*/

  // [교체] 저장 버튼(타입 보존 + 그룹 아웃라인 + 자식 도형 개별 기록) + 썸네일 PNG + 페이지 이동
  btnSaveJSON?.addEventListener('click', async () => {
    await ensurePc();
    saveDraftToSession();

    // 최상위만 추려내기(그룹 자식 제외)
    const childIds = new Set();
    state.objects.forEach(o => { if (o && o.kind === 'group') o.children.forEach(id => childIds.add(id)); });
    const topLevel = state.objects.filter(o => o && (o.kind === 'group' || !childIds.has(o.id)));
    if (topLevel.length === 0) {
      alert('保存できる図形がありません。');
      return;
    }

    // 출력 스키마(타입 보존 + 캔버스 크기 저장)
    const out = {
      version: 1,
      units: 'px',
      canvasSize: { width: canvas.width, height: canvas.height },
      shapes: []   // 빌더에서 읽을 리스트 (첫 항목이 전체 외곽이 되도록 배치)
    };

    // ── 헬퍼들 ───────────────────────────────────────────
    // ellipse 파라미터
    function ellipseParams(o) {
      return {
        cx: Math.round(o.x + o.w / 2),
        cy: Math.round(o.y + o.h / 2),
        rx: Math.round(Math.abs(o.w / 2)),
        ry: Math.round(Math.abs(o.h / 2)),
        angle: o.angle || 0
      };
    }

    // MultiPolygon → polygon 엔트리(여러 개면 여러 개 반환)
    function polygonEntriesFromMulti(multi, base) {
      const arr = [];
      multi.forEach(poly => {
        const outer = poly?.[0];
        if (!outer || outer.length === 0) return;
        const openOuter = stripClosure(outer).map(([x, y]) => [Math.round(x), Math.round(y)]);
        if (openOuter.length >= 3) {
          arr.push({ ...base, type: 'polygon', points: openOuter });
        }
      });
      return arr;
    }

    // 단일 도형 → polygon 엔트리(보통 1개)
    function polygonEntryFromShape(o) {
      const mp = shapeToPolygon(o); // [[ [ring] ]]
      const entries = polygonEntriesFromMulti(mp, {
        id: o.id, kind: 'shape',
        style: { fill: o.fill, stroke: o.stroke, lineWidth: o.lineWidth }
      });
      return entries[0] || null;
    }

    // 그룹 → 합집합 아웃라인 polygon 엔트리(1개 선택)
    function outlineEntryFromGroup(g) {
      if (!pcLib) return null;
      const multi = groupToPolygons(g, pcLib);
      for (const poly of multi) {
        const outer = poly?.[0];
        if (!outer || outer.length === 0) continue;
        const openOuter = stripClosure(outer).map(([x, y]) => [Math.round(x), Math.round(y)]);
        if (openOuter.length >= 3) {
          return {
            id: `${g.id}_outline`,
            kind: 'group',
            type: 'polygon',
            points: openOuter,
            role: 'outline' // (옵션) 식별용
          };
        }
      }
      return null;
    }

    // ── 저장 본문: "첫 shape는 전체 외곽"이 되도록 구성 ─────────────────────────
    // 1) 먼저 각 top-level 그룹의 "아웃라인"을 shapes에 넣어서 첫 항목이 되도록 함
    //    (빌더(building-facade.js)는 첫 폴리곤만 사용하므로 순서 중요!)
    for (const o of topLevel) {
      if (o.kind === 'group') {
        if (!pcLib) { alert('polygon-clipping が読み込まれていません。'); return; }
        const outline = outlineEntryFromGroup(o);
        if (outline) out.shapes.push(outline);
      }
    }

    // 2) top-level에 그룹이 없고 단일 도형만 있을 땐, 그 도형 자체를 첫 항목으로 추가
    if (!topLevel.some(o => o.kind === 'group')) {
      const o = topLevel[0];
      if (o) {
        if (o.type === 'circle') {
          const { cx, cy, rx, ry, angle } = ellipseParams(o);
          out.shapes.push({
            id: o.id, kind: 'shape', type: 'ellipse',
            cx, cy, rx, ry, angle,
            style: { fill: o.fill, stroke: o.stroke, lineWidth: o.lineWidth }
          });
        } else {
          const entry = polygonEntryFromShape(o);
          if (entry) out.shapes.push(entry);
        }
      }
    }

    // 3) 개별 도형(그룹의 자식 포함)을 타입 보존으로 전부 추가
    //    - circle → ellipse
    //    - 나머지 → polygon
    //    (빌더는 첫 항목만 사용하지만, 나중에 곡면/부재 분석용으로 메타 유지)
    const pushedIds = new Set(out.shapes.map(s => s.id));
    function pushShapeIfNew(entry) {
      if (!entry) return;
      if (entry.id && pushedIds.has(entry.id)) return;
      out.shapes.push(entry);
      if (entry.id) pushedIds.add(entry.id);
    }

    // 그룹 자식들
    for (const g of topLevel) {
      if (g.kind !== 'group') continue;
      for (const cid of g.children) {
        const ch = getObj(cid);
        if (!ch) continue;
        if (ch.type === 'circle') {
          const { cx, cy, rx, ry, angle } = ellipseParams(ch);
          pushShapeIfNew({
            id: ch.id, kind: 'shape', type: 'ellipse',
            cx, cy, rx, ry, angle,
            style: { fill: ch.fill, stroke: ch.stroke, lineWidth: ch.lineWidth }
          });
        } else {
          pushShapeIfNew(polygonEntryFromShape(ch));
        }
      }
    }

    // 그룹이 아닌 나머지 top-level 도형들(단독 도형)
    for (const o of topLevel) {
      if (o.kind === 'group') continue;
      if (o === topLevel[0] && out.shapes.length > 0) continue; // 이미 첫 항목으로 넣었음
      if (o.type === 'circle') {
        const { cx, cy, rx, ry, angle } = ellipseParams(o);
        pushShapeIfNew({
          id: o.id, kind: 'shape', type: 'ellipse',
          cx, cy, rx, ry, angle,
          style: { fill: o.fill, stroke: o.stroke, lineWidth: o.lineWidth }
        });
      } else {
        pushShapeIfNew(polygonEntryFromShape(o));
      }
    }

    // 파일명
    const ts = new Date();
    const pad = n => String(n).padStart(2, '0');
    const stamp = `${ts.getFullYear()}${pad(ts.getMonth() + 1)}${pad(ts.getDate())}_${pad(ts.getHours())}${pad(ts.getMinutes())}${pad(ts.getSeconds())}`;

    // JSON 저장(타입 보존)
    const jsonText = JSON.stringify(out, null, 2);
    const jsonBlob = new Blob([jsonText], { type: 'application/json' });
    downloadBlob(`floor_shapes_${stamp}.json`, jsonBlob);

    // 다음 페이지에서 바로 읽도록 세션에도 저장
    sessionStorage.setItem('floorShapesLatest', jsonText);



    //추가부분!!!!
    exportPNG(`floor_${stamp}.png`);  // 👉 이거 한 줄이면 PNG 저장 + 세션 저장 동시에 처리

    // 마지막에 페이지 이동
    sessionStorage.setItem('restoreOnReturn', '1');
    window.location.href = 'building_img.html';
  });





  /* =========================================================
   * 세션 16 / 초기화(init)
   * =======================================================*/

  async function init() {
    await ensurePc();
    state.snap = chkSnap?.checked ?? false;
    state.gridSize = parseInt(gridSizeInput?.value || '10', 10) || 10;
    restoreDraftFromSession();
    render();
  }

  // 시작!
  init();
})();
